# Keep crypto/JSON/VPN entry points; let R8 obfuscate everything else aggressively.
-dontwarn org.slf4j.**
-dontwarn kotlinx.coroutines.debug.**
-keepattributes *Annotation*
-keep class com.epicvpn.app.EpicVpnService { *; }
-keep class com.epicvpn.app.MainActivity { *; }
-keep class hev.htproxy.** { *; }

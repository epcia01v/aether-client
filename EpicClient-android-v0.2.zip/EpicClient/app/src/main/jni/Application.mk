APP_OPTIM := release
APP_PLATFORM := android-29
APP_ABI := arm64-v8a
APP_CFLAGS := -O3

package hev.htproxy;

/** JNI binding of hev-socks5-tunnel (MIT, github.com/heiher/hev-socks5-tunnel); the .so is built in CI. */
public final class TProxyService {
    static {
        System.loadLibrary("hev-socks5-tunnel");
    }

    public static native boolean TProxyStartService(String configPath, int fd);
    public static native boolean TProxyStopService();
    public static native boolean TProxyIsRunning();
    public static native long[] TProxyGetStats();

    private TProxyService() {}
}

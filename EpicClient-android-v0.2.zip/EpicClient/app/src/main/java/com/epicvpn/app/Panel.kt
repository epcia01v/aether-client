package com.epicvpn.app

import android.content.Context
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Fetches ready-made configs from the PHP panel (owner tool; unused in the customer edition). */
object Panel {
    fun fetch(ctx: Context, url: String, params: Map<String, String>) {
        Thread {
            var msg = ""
            try {
                val body = params.entries.joinToString("&") {
                    URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
                }
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 10_000
                c.readTimeout = 15_000
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                c.outputStream.use { it.write(body.toByteArray()) }
                val code = c.responseCode
                if (code != 200) {
                    msg = if (code == 403) "رمز پنل اشتباه است" else "پنل خطا داد ($code)"
                } else {
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    ui { AppState.addLinks(ctx, text) }
                    msg = if (text.contains("epx://")) "کانفیگ‌ها از پنل دریافت شد" else "لینکی دریافت نشد؛ آدرس پنل را بررسی کنید"
                }
            } catch (e: Exception) {
                msg = "خطا در اتصال به پنل: ${e.message}"
            }
            ui { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }
}

package com.epicvpn.app

/** Tiny two-language helper: reads AppState.lang, so composables that call it recompose on language change. */
fun tr(fa: String, en: String): String = if (AppState.lang == "en") en else fa

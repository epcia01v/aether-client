package com.epicvpn.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.net.URI
import java.net.URLDecoder

/** delay: 0 = not tested, -1 = failed, >0 = milliseconds */
data class Cfg(
    val raw: String,
    val name: String,
    val host: String,
    val port: Int,
    val protocol: String,
    val scan: String,
    val ip: String,
    val exp: Long = 0,
    val licId: String? = null,
    val panelUrl: String? = null,
    val loc: String = "",
    val delay: Int = 0,
) {
    val id: String get() = raw
    /** Encrypted epx:// config: address is hidden and usage is controlled by the panel. */
    val locked: Boolean get() = licId != null
    /** exp = unix seconds, 0 = never expires. Client-side only: it can be edited out of the link. */
    val expired: Boolean
        get() {
            val lid = licId
            if (lid != null) {
                val s = AppState.lic[lid] ?: return false
                return s.status != "active" || (s.exp > 0 && System.currentTimeMillis() / 1000 > s.exp)
            }
            return exp > 0 && System.currentTimeMillis() / 1000 > exp
        }
    val badge: String
        get() = when (protocol) {
            "masque" -> "MQ"
            "gool" -> "GOOL"
            "mim" -> "MIM"
            else -> "WG"
        }
}

private fun parseToken(t: String): Cfg? {
    val j = Lic.decrypt(t) ?: return null
    val id = j.optString("id").takeIf { it.isNotEmpty() } ?: return null
    return Cfg(
        raw = t,
        name = j.optString("n").ifBlank { "Epic" },
        host = "", port = 0,
        protocol = j.optString("p", "wg"),
        scan = j.optString("s", "balanced"),
        ip = when (j.optString("ip")) { "4" -> "v4"; "6" -> "v6"; else -> "both" },
        licId = id,
        panelUrl = j.optString("u").takeIf { it.isNotEmpty() },
        loc = j.optString("l", "").uppercase().filter { it.isLetter() },
    )
}

fun parseLink(s: String): Cfg? {
    val t = s.trim()
    if (t.startsWith("epx://")) return parseToken(t)
    if (Edition.CUSTOMER) return null
    if (!t.startsWith("epx://")) return null
    return try {
        val u = URI(t)
        val host = u.host ?: return null
        val port = if (u.port > 0) u.port else return null
        val q = (u.rawQuery ?: "").split("&")
            .filter { "=" in it }
            .associate { it.substringBefore("=") to URLDecoder.decode(it.substringAfter("="), "UTF-8") }
        val name = u.rawFragment?.let { URLDecoder.decode(it, "UTF-8") }?.takeIf { it.isNotBlank() }
            ?: "$host:$port"
        val ip = when (q["ip"]?.lowercase()) {
            "4", "v4", "ipv4" -> "v4"
            "6", "v6", "ipv6" -> "v6"
            else -> "both"
        }
        Cfg(
            raw = t, name = name, host = host, port = port,
            protocol = q["protocol"]?.lowercase() ?: "wg",
            scan = q["scan"]?.lowercase() ?: "balanced",
            ip = ip,
            exp = q["exp"]?.toLongOrNull() ?: 0L,
        )
    } catch (e: Exception) {
        null
    }
}

private val mainHandler = Handler(Looper.getMainLooper())
fun ui(f: () -> Unit) { mainHandler.post(f) }

object AppState {
    val configs = mutableStateListOf<Cfg>()
    val log = mutableStateListOf<String>()
    val lic = mutableStateMapOf<String, LicState>()
    var selected by mutableStateOf<String?>(null)
    var connected by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var message by mutableStateOf("")
    var testing by mutableStateOf(false)
    var testingId by mutableStateOf<String?>(null)
    var usePeer by mutableStateOf(false)
    var vpnMode by mutableStateOf(true)
    var lastError by mutableStateOf("")
    var panelUrl by mutableStateOf("")
    var panelPass by mutableStateOf("")
    var showLog by mutableStateOf(false)
    var connectedAt by mutableStateOf(0L)
    var txBytes by mutableStateOf(0L)
    var rxBytes by mutableStateOf(0L)

    /** 0 = off, 1 = connecting, 2 = connected */
    val state: Int get() = if (connected) 2 else if (busy) 1 else 0

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences("epic", 0)
        configs.clear()
        sp.getString("links", "")!!.split("\n").mapNotNull { parseLink(it) }.forEach { configs.add(it) }
        selected = sp.getString("sel", null)?.takeIf { s -> configs.any { it.id == s } } ?: configs.firstOrNull()?.id
        usePeer = sp.getBoolean("peer", false)
        vpnMode = sp.getBoolean("vpn", true)
        panelUrl = sp.getString("panelUrl", "") ?: ""
        panelPass = sp.getString("panelPass", "") ?: ""
        lic.clear()
        (ctx.getSharedPreferences("lic", 0).getString("all", "") ?: "").split("\n").forEach { line ->
            val f = line.split(",")
            if (f.size == 4) lic[f[0]] = LicState(f[1], f[2].toLongOrNull() ?: 0L, f[3].toLongOrNull() ?: 0L)
        }
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("epic", 0).edit()
            .putString("links", configs.joinToString("\n") { it.raw })
            .putString("sel", selected)
            .putBoolean("peer", usePeer)
            .putBoolean("vpn", vpnMode)
            .putString("panelUrl", panelUrl)
            .putString("panelPass", panelPass)
            .apply()
    }

    fun saveLic(ctx: Context) {
        ctx.getSharedPreferences("lic", 0).edit()
            .putString("all", lic.entries.joinToString("\n") { "${it.key},${it.value.status},${it.value.exp},${it.value.lastOk}" })
            .apply()
    }

    fun addLinks(ctx: Context, text: String): Int {
        var n = 0
        val added = mutableListOf<Cfg>()
        lastError = ""
        text.split(Regex("\\s+")).filter { it.isNotBlank() }.forEach { part ->
            val c = parseLink(part)
            if (c == null) {
                if (part.startsWith("epx://") || part.startsWith("epx://")) lastError = Lic.importProblem(part)
            } else if (configs.none { it.id == c.id }) {
                configs.add(c); added.add(c); n++
            } else {
                lastError = "این کانفیگ قبلاً اضافه شده است."
            }
        }
        if (selected == null) selected = configs.firstOrNull()?.id
        save(ctx)
        Lic.refresh(ctx, added)   // activate new encrypted configs right away
        return n
    }

    /** Replace config [oldId] with [c] (edit) or add [c] (create) and select it. */
    fun upsert(ctx: Context, oldId: String?, c: Cfg) {
        configs.removeAll { it.id == c.id && it.id != oldId }
        val i = if (oldId != null) configs.indexOfFirst { it.id == oldId } else -1
        if (i >= 0) {
            configs[i] = c
        } else {
            configs.add(c)
        }
        if (oldId == null || selected == oldId) selected = c.id
        save(ctx)
    }

    fun remove(ctx: Context, id: String) {
        configs.removeAll { it.id == id }
        if (selected == id) selected = configs.firstOrNull()?.id
        save(ctx)
    }

    fun setDelay(id: String, d: Int) = ui {
        val i = configs.indexOfFirst { it.id == id }
        if (i >= 0) configs[i] = configs[i].copy(delay = d)
    }

    fun log(line: String) = ui {
        log.add(line)
        while (log.size > 200) log.removeAt(0)
    }
}

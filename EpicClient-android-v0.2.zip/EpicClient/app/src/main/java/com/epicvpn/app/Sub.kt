package com.epicvpn.app

import android.content.Context
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL

/** Subscription links from the panel: https://host/index.php?s=<24 chars>. The app fetches the config behind it. */
object Sub {
    private val shape = Regex("[?&]s=[a-z0-9]{16,}", RegexOption.IGNORE_CASE)

    fun isLink(s: String): Boolean {
        val t = s.trim()
        return (t.startsWith("https://") || t.startsWith("http://")) && shape.containsMatchIn(t)
    }

    fun import(ctx: Context, link: String) {
        Toast.makeText(ctx, tr("در حال دریافت اشتراک…", "Fetching subscription…"), Toast.LENGTH_SHORT).show()
        Thread {
            var token = ""
            var msg = ""
            try {
                val base = link.trim().substringBefore("#")
                val u = base + (if (base.contains("?")) "&" else "?") + "fmt=epx"
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 12_000
                c.readTimeout = 15_000
                val code = c.responseCode
                if (code == 200) {
                    val text = c.inputStream.bufferedReader().use { it.readText() }.trim()
                    if (text.startsWith("epx://")) token = text else msg = tr("پاسخ سرور معتبر نبود", "Invalid server response")
                } else {
                    msg = when (code) {
                        403 -> tr("این اشتراک ابطال شده است", "This subscription was revoked")
                        404 -> tr("لینک اشتراک معتبر نیست", "Subscription link is not valid")
                        429 -> tr("تلاش بیش از حد؛ کمی بعد دوباره امتحان کنید", "Too many attempts, try again later")
                        else -> "HTTP $code"
                    }
                }
            } catch (e: Exception) {
                msg = tr("خطا در اتصال: ", "Connection error: ") + (e.message ?: "")
            }
            ui {
                if (token.isNotEmpty()) AppState.importText(ctx, token)
                else Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            }
        }.start()
    }
}

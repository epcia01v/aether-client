package com.epicvpn.app

import com.journeyapps.barcodescanner.CaptureActivity

/** QR scanner screen (zxing-android-embedded) that follows the phone's orientation instead of forcing landscape. */
class PortraitCapture : CaptureActivity()

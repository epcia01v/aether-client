package com.epicvpn.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/** Lucide icons (ISC licence, lucide.dev) as stroke-only vectors; tint them with Icon(tint = ...). */
object Lucide {
    private val data: Map<String, List<String>> = mapOf(
        "copy" to listOf("M10 8 H20 A2 2 0 0 1 22 10 V20 A2 2 0 0 1 20 22 H10 A2 2 0 0 1 8 20 V10 A2 2 0 0 1 10 8 Z", "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"),
        "qr" to listOf("M4 3 H7 A1 1 0 0 1 8 4 V7 A1 1 0 0 1 7 8 H4 A1 1 0 0 1 3 7 V4 A1 1 0 0 1 4 3 Z", "M17 3 H20 A1 1 0 0 1 21 4 V7 A1 1 0 0 1 20 8 H17 A1 1 0 0 1 16 7 V4 A1 1 0 0 1 17 3 Z", "M4 16 H7 A1 1 0 0 1 8 17 V20 A1 1 0 0 1 7 21 H4 A1 1 0 0 1 3 20 V17 A1 1 0 0 1 4 16 Z", "M21 16h-3a2 2 0 0 0-2 2v3", "M21 21v.01", "M12 7v3a2 2 0 0 1-2 2H7", "M3 12h.01", "M12 3h.01", "M12 16v.01", "M16 12h1", "M21 12v.01", "M12 21v-1"),
        "sun" to listOf("M8 12 A4 4 0 1 0 16 12 A4 4 0 1 0 8 12 Z", "M12 2v2", "M12 20v2", "m4.93 4.93 1.41 1.41", "m17.66 17.66 1.41 1.41", "M2 12h2", "M20 12h2", "m6.34 17.66-1.41 1.41", "m19.07 4.93-1.41 1.41"),
        "moon" to listOf("M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"),
        "lang" to listOf("m5 8 6 6", "m4 14 6-6 2-3", "M2 5h12", "M7 2h1", "m22 22-5-10-5 10", "M14 18h6"),
        "users" to listOf("M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", "M5 7 A4 4 0 1 0 13 7 A4 4 0 1 0 5 7 Z", "M22 21v-2a4 4 0 0 0-3-3.87", "M16 3.13a4 4 0 0 1 0 7.75"),
        "link" to listOf("M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71", "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"),
        "plus" to listOf("M5 12h14", "M12 5v14"),
        "trash" to listOf("M3 6h18", "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", "M10 11 L10 17", "M14 11 L14 17"),
        "ban" to listOf("M2 12 A10 10 0 1 0 22 12 A10 10 0 1 0 2 12 Z", "m4.9 4.9 14.2 14.2"),
        "refresh" to listOf("M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", "M3 3v5h5"),
        "clock" to listOf("M2 12 A10 10 0 1 0 22 12 A10 10 0 1 0 2 12 Z", "M12 6 L12 12 L16 14"),
        "logout" to listOf("M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", "M16 17 L21 12 L16 7", "M21 12 L9 12"),
        "shield" to listOf("M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z", "m9 12 2 2 4-4"),
        "globe" to listOf("M2 12 A10 10 0 1 0 22 12 A10 10 0 1 0 2 12 Z", "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20", "M2 12h20"),
        "zap" to listOf("M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"),
        "phone" to listOf("M7 2 H17 A2 2 0 0 1 19 4 V20 A2 2 0 0 1 17 22 H7 A2 2 0 0 1 5 20 V4 A2 2 0 0 1 7 2 Z", "M12 18h.01"),
        "calendar" to listOf("M8 2v4", "M16 2v4", "M5 4 H19 A2 2 0 0 1 21 6 V20 A2 2 0 0 1 19 22 H5 A2 2 0 0 1 3 20 V6 A2 2 0 0 1 5 4 Z", "M3 10h18"),
        "external" to listOf("M15 3h6v6", "M10 14 21 3", "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"),
        "check" to listOf("M20 6 9 17l-5-5"),
        "userplus" to listOf("M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", "M5 7 A4 4 0 1 0 13 7 A4 4 0 1 0 5 7 Z", "M19 8 L19 14", "M22 11 L16 11"),
        "key" to listOf("m21 2-9.6 9.6", "M2 15.5 A5.5 5.5 0 1 0 13 15.5 A5.5 5.5 0 1 0 2 15.5 Z", "m15.5 7.5 3 3L22 7l-3-3"),
        "database" to listOf("M3 5 A9 3 0 1 0 21 5 A9 3 0 1 0 3 5 Z", "M3 5v14a9 3 0 0 0 18 0V5", "M3 12a9 3 0 0 0 18 0"),
        "power" to listOf("M12 2v10", "M18.4 6.6a9 9 0 1 1-12.77.04"),
        "clipboard" to listOf("M9 2 H15 A1 1 0 0 1 16 3 V5 A1 1 0 0 1 15 6 H9 A1 1 0 0 1 8 5 V3 A1 1 0 0 1 9 2 Z", "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"),
        "scan" to listOf("M3 7V5a2 2 0 0 1 2-2h2", "M17 3h2a2 2 0 0 1 2 2v2", "M21 17v2a2 2 0 0 1-2 2h-2", "M7 21H5a2 2 0 0 1-2-2v-2", "M7 12h10"),
        "share" to listOf("M15 5 A3 3 0 1 0 21 5 A3 3 0 1 0 15 5 Z", "M3 12 A3 3 0 1 0 9 12 A3 3 0 1 0 3 12 Z", "M15 19 A3 3 0 1 0 21 19 A3 3 0 1 0 15 19 Z", "M8.59 13.51 L15.42 17.49", "M15.41 6.51 L8.59 10.49"),
    )
    private val cache = HashMap<String, ImageVector>()

    fun get(name: String): ImageVector = cache.getOrPut(name) {
        val b = ImageVector.Builder(
            name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f,
        )
        (data[name] ?: emptyList()).forEach { d ->
            b.addPath(
                pathData = addPathNodes(d),
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            )
        }
        b.build()
    }
}

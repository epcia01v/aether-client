package com.epicvpn.app

import android.net.Uri
import java.security.SecureRandom

/** Builds raw:// links locally (same format as the PHP panel). */
object Gen {
    private val ports = intArrayOf(
        500, 854, 859, 864, 878, 880, 890, 891, 894, 903, 908, 928, 934, 939, 942, 943, 945, 946, 955,
        968, 987, 988, 1002, 1010, 1014, 1018, 1070, 1074, 1180, 1387, 1701, 1843, 2371, 2408, 2506,
        3138, 3476, 3581, 3854, 4177, 4198, 4233, 4500, 5279, 5956, 7103, 7152, 7156, 7281, 7559,
        8319, 8742, 8854, 8886,
    )
    private val prefixes = listOf(
        "162.159.192", "162.159.193", "162.159.195", "188.114.96", "188.114.97", "188.114.98", "188.114.99",
    )
    private val rnd = SecureRandom()

    fun randomEndpoint(): String =
        "${prefixes[rnd.nextInt(prefixes.size)]}.${1 + rnd.nextInt(254)}:${ports[rnd.nextInt(ports.size)]}"

    fun randomName(prefix: String = ""): String {
        val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        return prefix + (1..6).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
    }

    /** unit: none | hour | day. Returns unix seconds or 0. */
    fun expFrom(unit: String, amount: String): Long {
        val a = (amount.toLongOrNull() ?: 1L).coerceIn(1L, 3650L)
        val now = System.currentTimeMillis() / 1000
        return when (unit) {
            "hour" -> now + a * 3600
            "day" -> now + a * 86400
            else -> 0L
        }
    }

    fun build(name: String, endpoint: String, protocol: String, scan: String, ip: String, exp: Long): String {
        val q = "protocol=$protocol&scan=$scan&ip=$ip" + if (exp > 0) "&exp=$exp" else ""
        return "raw://$endpoint?$q#${Uri.encode(name)}"
    }
}

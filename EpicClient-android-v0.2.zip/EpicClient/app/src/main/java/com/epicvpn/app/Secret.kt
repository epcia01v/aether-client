package com.epicvpn.app

/**
 * Placeholder. The GitHub workflow overwrites this file at build time with the real values
 * (repository secrets EPIC_AES_KEY and EPIC_PUB_KEY from the panel).
 *
 * AES_KEY decrypts config tokens (address/protocol/etc.) - if it ever leaks, someone could only
 * read that metadata, not forge a license.
 * PUB_KEY only verifies the panel's signature; it is not sensitive even if it leaks, because the
 * matching private key stays on the server and is never shipped in the app.
 */
object Secret {
    const val AES_KEY = ""
    const val PUB_KEY = ""
}

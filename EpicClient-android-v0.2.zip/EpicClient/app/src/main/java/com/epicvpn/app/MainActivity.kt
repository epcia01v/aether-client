package com.epicvpn.app

import android.Manifest
import androidx.activity.SystemBarStyle
import androidx.compose.material3.IconButton
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.unit.Dp
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppState.load(this)
        Lic.refresh(this, AppState.configs.toList())
        handle(intent)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { App() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val d = i?.dataString ?: return
        AppState.importText(this, d)
    }
}

// ---------------------------------------------------------------- theme

private val Green = Color(0xFF34C759)
private val Amber = Color(0xFFFF9F0A)
private val Red = Color(0xFFFF3B30)

// iOS-style palette: system blue + purple accent on soft grouped backgrounds.
private val Blue = Color(0xFF0A84FF)
private val Purple = Color(0xFFAF52DE)
private val EpicGradient = Brush.linearGradient(listOf(Color(0xFF0A84FF), Color(0xFFAF52DE)))

private val AppFont = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF0A84FF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF0B2A4A),
    onPrimaryContainer = Color(0xFFD6E8FF),
    background = Color(0xFF000000),
    onBackground = Color(0xFFF5F5F7),
    surface = Color(0xFF1C1C1E),
    onSurface = Color(0xFFF5F5F7),
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = Color(0xFF98989F),
    outline = Color(0xFF48484A),
    error = Color(0xFFFF453A),
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF007AFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEBFF),
    onPrimaryContainer = Color(0xFF00305F),
    background = Color(0xFFF2F2F7),
    onBackground = Color(0xFF111114),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF111114),
    surfaceVariant = Color(0xFFE9E9EE),
    onSurfaceVariant = Color(0xFF6C6C72),
    outline = Color(0xFFD1D1D6),
    error = Color(0xFFFF3B30),
)

@Composable
private fun isDark(): Boolean = when (AppState.themeMode) {
    1 -> false
    2 -> true
    else -> isSystemInDarkTheme()
}

@Composable
fun App() {
    val dark = isDark()
    val scheme: ColorScheme = if (dark) DarkScheme else LightScheme
    val rtl = AppState.lang != "en"
    val act = LocalContext.current as? ComponentActivity
    SideEffect {
        val bars = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        act?.enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
    }
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
            ProvideTextStyle(TextStyle(fontFamily = AppFont)) {
                Box(Modifier.fillMaxSize().background(scheme.background)) {
                    GlowBackground(dark)
                    Home()
                }
            }
        }
    }
}

/** Soft colored glows behind everything; gives the cards something to sit on, like iOS wallpapers. */
@Composable
private fun GlowBackground(dark: Boolean) {
    val a = if (dark) 0.30f else 0.20f
    Box(
        Modifier.fillMaxSize().drawBehind {
            val w = size.width
            val h = size.height
            val c1 = Offset(w * 0.10f, h * 0.02f)
            val c2 = Offset(w * 0.95f, h * 0.30f)
            val c3 = Offset(w * 0.30f, h * 0.98f)
            drawCircle(brush = Brush.radialGradient(listOf(Blue.copy(alpha = a), Color.Transparent), center = c1, radius = w * 0.95f), radius = w * 0.95f, center = c1)
            drawCircle(brush = Brush.radialGradient(listOf(Purple.copy(alpha = a * 0.8f), Color.Transparent), center = c2, radius = w * 0.8f), radius = w * 0.8f, center = c2)
            drawCircle(brush = Brush.radialGradient(listOf(Blue.copy(alpha = a * 0.6f), Color.Transparent), center = c3, radius = w * 0.9f), radius = w * 0.9f, center = c3)
        },
    )
}

@Composable
private fun LIcon(name: String, size: Dp = 20.dp, tint: Color = LocalContentColor.current) {
    Icon(imageVector = Lucide.get(name), contentDescription = null, tint = tint, modifier = Modifier.size(size))
}

@Composable
private fun Glass(modifier: Modifier = Modifier, radius: Dp = 24.dp, border: Color? = null, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(radius),
        color = cs.surface.copy(alpha = 0.78f),
        border = BorderStroke(if (border != null) 1.5.dp else 1.dp, border ?: cs.outline.copy(alpha = 0.55f)),
    ) { content() }
}

@Composable
private fun Chip(text: String, color: Color) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.14f)).padding(horizontal = 9.dp, vertical = 2.dp)) {
        Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
    }
}

// ---------------------------------------------------------------- helpers

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

private fun startVpn(ctx: Context) {
    val id = AppState.selected ?: return
    ctx.startForegroundService(Intent(ctx, EpicVpnService::class.java).putExtra("id", id))
}

private fun stopVpn(ctx: Context) {
    ctx.startService(Intent(ctx, EpicVpnService::class.java).setAction(EpicVpnService.ACTION_STOP))
}

private fun pasteFromClipboard(ctx: Context) {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
    if (t.isBlank()) toast(ctx, tr("کلیپ‌بورد خالی است", "Clipboard is empty")) else AppState.importText(ctx, t)
}

private fun shareLink(ctx: Context, link: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, link)
    ctx.startActivity(Intent.createChooser(i, "اشتراک‌گذاری کانفیگ"))
}

/** Two-letter country code -> its flag emoji, built from Unicode regional indicators; no lookup table needed. */
private fun flagEmoji(cc: String): String {
    if (cc.length != 2) return ""
    return cc.uppercase().map { ch -> 0x1F1E6 + (ch - 'A') }
        .takeIf { it.all { cp -> cp in 0x1F1E6..0x1F1FF } }
        ?.joinToString("") { String(Character.toChars(it)) } ?: ""
}

private fun fmtBytes(b: Long): String {
    val units = arrayOf("B", "KB", "MB", "GB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return if (i == 0) "$b B" else String.format(Locale.US, "%.1f %s", v, units[i])
}

private fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}

// ---------------------------------------------------------------- dialogs state

private sealed interface Dlg {
    object Create : Dlg
    class Edit(val cfg: Cfg) : Dlg
    object Panel : Dlg
}

private class Form(
    name: String = "",
    protocol: String = "wg",
    scan: String = "balanced",
    ip: String = "both",
    endpoint: String = "",
    unit: String = "none",
    amount: String = "1",
    count: String = "5",
) {
    var name by mutableStateOf(name)
    var protocol by mutableStateOf(protocol)
    var scan by mutableStateOf(scan)
    var ip by mutableStateOf(ip)
    var endpoint by mutableStateOf(endpoint)
    var unit by mutableStateOf(unit)
    var amount by mutableStateOf(amount)
    var count by mutableStateOf(count)
}

private fun formOf(c: Cfg) = Form(
    name = c.name, protocol = c.protocol, scan = c.scan,
    ip = when (c.ip) { "v4" -> "4"; "v6" -> "6"; else -> "both" },
    endpoint = "${c.host}:${c.port}",
    unit = if (c.exp > 0) "keep" else "none",
)

private val PROTOCOLS = listOf("wg" to "WireGuard", "masque" to "MASQUE", "gool" to "Gool")
private val SCANS = listOf("turbo" to "turbo", "balanced" to "balanced", "thorough" to "thorough", "verified" to "verified", "ironclad" to "ironclad")
private val IPS = listOf("both" to "هر دو", "4" to "IPv4", "6" to "IPv6")

@Composable
private fun Choice(label: String, options: List<Pair<String, String>>, value: String, onChange: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(label, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (k, t) ->
            val sel = k == value
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) cs.primary else cs.surfaceVariant)
                    .clickable { onChange(k) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(t, fontSize = 13.sp, color = if (sel) cs.onPrimary else cs.onSurface) }
        }
    }
}

@Composable
private fun FormFields(f: Form, showName: Boolean, showEndpoint: Boolean, canKeep: Boolean) {
    val ltr = TextStyle(textDirection = TextDirection.Ltr)
    if (showName) {
        OutlinedTextField(
            value = f.name, onValueChange = { f.name = it }, singleLine = true,
            label = { Text("نام کانفیگ") }, modifier = Modifier.fillMaxWidth(),
        )
    }
    if (showEndpoint) {
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = f.endpoint, onValueChange = { f.endpoint = it }, singleLine = true, textStyle = ltr,
            label = { Text("آدرس:پورت (خالی = تصادفی)") }, modifier = Modifier.fillMaxWidth(),
        )
        TextButton(onClick = { f.endpoint = Gen.randomEndpoint() }) { Text("آدرس تصادفی جدید") }
    }
    Choice("پروتکل", PROTOCOLS, f.protocol) { f.protocol = it }
    Choice("حالت اسکن", SCANS, f.scan) { f.scan = it }
    Choice("نسخه IP", IPS, f.ip) { f.ip = it }
    val units = buildList<Pair<String, String>> {
        add("none" to "بدون انقضا"); add("hour" to "ساعت"); add("day" to "روز")
        if (canKeep) add("keep" to "حفظ انقضای فعلی")
    }
    Choice("مدت اعتبار", units, f.unit) { f.unit = it }
    if (f.unit == "hour" || f.unit == "day") {
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = f.amount, onValueChange = { f.amount = it.filter(Char::isDigit).take(4) }, singleLine = true,
            label = { Text(if (f.unit == "hour") "چند ساعت؟" else "چند روز؟") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun CfgDialog(ctx: Context, existing: Cfg?, onClose: () -> Unit) {
    val form = remember { if (existing == null) Form(name = Gen.randomName("epic-"), endpoint = Gen.randomEndpoint()) else formOf(existing) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (existing == null) "ساخت کانفیگ" else "ویرایش کانفیگ") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { FormFields(form, true, true, existing != null && existing.exp > 0) } },
        confirmButton = {
            TextButton(onClick = {
                val ep = form.endpoint.trim().ifEmpty { Gen.randomEndpoint() }
                val name = form.name.trim().ifEmpty { Gen.randomName("epic-") }
                val exp = if (form.unit == "keep") existing?.exp ?: 0L else Gen.expFrom(form.unit, form.amount)
                val cfg = parseLink(Gen.build(name, ep, form.protocol, form.scan, form.ip, exp))
                if (cfg == null) {
                    toast(ctx, "آدرس معتبر نیست؛ مثال: 162.159.192.1:2408")
                } else {
                    AppState.upsert(ctx, existing?.id, cfg)
                    toast(ctx, if (existing == null) "کانفیگ ساخته شد" else "ذخیره شد")
                    onClose()
                }
            }) { Text("تأیید") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("انصراف") } },
    )
}

@Composable
private fun PanelDialog(ctx: Context, onClose: () -> Unit) {
    val form = remember { Form() }
    var url by remember { mutableStateOf(AppState.panelUrl) }
    var pass by remember { mutableStateOf(AppState.panelPass) }
    val ltr = TextStyle(textDirection = TextDirection.Ltr)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("دریافت از پنل") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = url, onValueChange = { url = it.trim() }, singleLine = true, textStyle = ltr,
                    label = { Text("آدرس پنل (index.php)") }, placeholder = { Text("https://example.com/index.php") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = pass, onValueChange = { pass = it }, singleLine = true, textStyle = ltr,
                    label = { Text("رمز پنل (اگر دارد)") }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = form.count, onValueChange = { form.count = it.filter(Char::isDigit).take(3) }, singleLine = true,
                    label = { Text("تعداد کانفیگ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                FormFields(form, false, false, false)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (!url.startsWith("http")) {
                    toast(ctx, "آدرس پنل باید با http یا https شروع شود")
                } else {
                    AppState.panelUrl = url
                    AppState.panelPass = pass
                    AppState.save(ctx)
                    Panel.fetch(
                        ctx, url,
                        mapOf(
                            "api" to "1", "pass" to pass, "count" to form.count.ifEmpty { "5" },
                            "protocol" to form.protocol, "scan" to form.scan, "ip" to form.ip,
                            "unit" to form.unit, "amount" to form.amount,
                        ),
                    )
                    toast(ctx, "در حال دریافت…")
                    onClose()
                }
            }) { Text("دریافت") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("انصراف") } },
    )
}

// ---------------------------------------------------------------- screen

@Composable
private fun Home() {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn(ctx)
    }
    val scanLauncher = rememberLauncherForActivityResult(ScanContract()) { r ->
        val t = r.contents
        if (!t.isNullOrBlank()) AppState.importText(ctx, t)
    }
    val scanPrompt = tr("QR کانفیگ را داخل کادر بگیرید", "Point the camera at the config QR")
    val onScan: () -> Unit = {
        val o = ScanOptions()
        o.setDesiredBarcodeFormats(ScanOptions.QR_CODE)
        o.setPrompt(scanPrompt)
        o.setBeepEnabled(false)
        o.setOrientationLocked(false)
        o.setCaptureActivity(PortraitCapture::class.java)
        scanLauncher.launch(o)
    }
    val onToggle: () -> Unit = {
        if (AppState.connected || AppState.busy) {
            stopVpn(ctx)
        } else if (AppState.configs.find { it.id == AppState.selected }?.expired == true) {
            toast(ctx, tr("این کانفیگ منقضی شده است", "This config has expired"))
        } else if (!AppState.testing && AppState.selected != null) {
            val i = if (AppState.vpnMode) VpnService.prepare(ctx) else null
            if (i != null) vpnLauncher.launch(i) else startVpn(ctx)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Header(ctx) }
        item { Hero(onToggle) }
        item { AddBar(ctx, onScan = onScan, onCreate = { dlg = Dlg.Create }, onPanel = { dlg = Dlg.Panel }) }
        if (AppState.configs.isEmpty()) {
            item { EmptyCard(onScan) }
        } else {
            items(AppState.configs, key = { it.id }) { c -> CfgCard(ctx, c, onEdit = { dlg = Dlg.Edit(c) }) }
        }
        item { SettingsCard(ctx) }
        item { Spacer(Modifier.height(24.dp)) }
    }

    when (val d = dlg) {
        is Dlg.Create -> CfgDialog(ctx, null) { dlg = null }
        is Dlg.Edit -> CfgDialog(ctx, d.cfg) { dlg = null }
        is Dlg.Panel -> PanelDialog(ctx) { dlg = null }
        null -> {}
    }
}

@Composable
private fun RoundBtn(onClick: () -> Unit, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(cs.surfaceVariant.copy(alpha = 0.85f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun Header(ctx: Context) {
    val cs = MaterialTheme.colorScheme
    val dark = isDark()
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(EpicGradient),
            contentAlignment = Alignment.Center,
        ) { LIcon("zap", 22.dp, Color.White) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Epic", fontSize = 26.sp, fontWeight = FontWeight.Black, color = cs.onBackground)
            Text(tr("اینترنت آزاد، یک‌لمسی", "Open internet, one tap"), fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
        RoundBtn(onClick = { AppState.lang = if (AppState.lang == "en") "fa" else "en"; AppState.save(ctx) }) {
            Text(if (AppState.lang == "en") "فا" else "EN", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
        }
        Spacer(Modifier.width(8.dp))
        RoundBtn(onClick = { AppState.themeMode = if (dark) 1 else 2; AppState.save(ctx) }) {
            LIcon(if (dark) "sun" else "moon", 18.dp, cs.onSurface)
        }
    }
}

@Composable
private fun Hero(onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val state = AppState.state
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(AppState.connected) {
        while (AppState.connected) {
            now = SystemClock.elapsedRealtime()
            delay(1000)
        }
    }
    val sel = AppState.configs.find { it.id == AppState.selected }
    val port = if (sel != null) Core.proxyPort(sel, Core.MAIN_PORT) else Core.MAIN_PORT

    Glass(Modifier.fillMaxWidth(), radius = 30.dp, border = if (state == 2) Green.copy(alpha = 0.6f) else null) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 24.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            PowerButton(state, onToggle)
            Spacer(Modifier.height(14.dp))
            Text(
                when (state) { 2 -> tr("متصل", "Connected"); 1 -> tr("در حال اتصال…", "Connecting…"); else -> tr("قطع", "Disconnected") },
                fontSize = 26.sp, fontWeight = FontWeight.Bold,
                color = when (state) { 2 -> Green; 1 -> Amber; else -> cs.onSurface },
            )
            Spacer(Modifier.height(4.dp))
            val sub = when {
                state == 1 -> tr("پیدا کردن بهترین مسیر، تا ۹۰ ثانیه ممکن است طول بکشد", "Finding the best route, this can take up to 90 seconds")
                state == 0 && AppState.message.isNotEmpty() -> AppState.message
                state == 2 && AppState.message.isNotEmpty() -> AppState.message
                state == 2 && !AppState.vpnMode -> tr("پراکسی SOCKS5 روی 127.0.0.1:$port فعال است", "SOCKS5 proxy is running on 127.0.0.1:$port")
                sel != null -> sel.name
                else -> tr("کانفیگ خود را اضافه کنید", "Add your config to start")
            }
            Text(
                sub, fontSize = 13.sp, textAlign = TextAlign.Center,
                color = if (state == 0 && AppState.message.isNotEmpty()) cs.error
                        else if (state == 2 && AppState.message.isNotEmpty()) Amber
                        else cs.onSurfaceVariant,
            )
            if (state == 2) {
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stat(tr("زمان", "Time"), fmtTime(now - AppState.connectedAt))
                    Stat(tr("دانلود", "Download"), fmtBytes(AppState.rxBytes))
                    Stat(tr("آپلود", "Upload"), fmtBytes(AppState.txBytes))
                    val loc = AppState.detectedLoc
                    if (loc.isNotEmpty()) Stat(tr("کشور", "Country"), "${flagEmoji(loc)} $loc")
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    val cs = MaterialTheme.colorScheme
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = cs.onSurface)
        Text(label, fontSize = 11.sp, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun PowerButton(state: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val inf = rememberInfiniteTransition(label = "pulse")
    val pulse by inf.animateFloat(
        initialValue = 0.94f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue",
    )
    val col by animateColorAsState(
        when (state) { 2 -> Green; 1 -> Amber; else -> cs.onSurfaceVariant },
        label = "powerColor",
    )
    val ring = if (state == 0) Brush.linearGradient(listOf(col, col)) else EpicGradient
    Box(Modifier.size(176.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(176.dp).scale(if (state == 1) pulse else 1f).clip(CircleShape).background(col.copy(alpha = 0.10f)))
        Box(Modifier.size(142.dp).clip(CircleShape).background(col.copy(alpha = 0.16f)))
        Box(
            Modifier.size(108.dp).clip(CircleShape).background(ring).clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(100.dp).clip(CircleShape).background(cs.surface))
            LIcon("power", 40.dp, col)
        }
    }
}

@Composable
private fun ActionTile(icon: String, label: String, modifier: Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tint = if (enabled) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.5f)
    Glass(modifier.clip(RoundedCornerShape(22.dp)).clickable(enabled = enabled, onClick = onClick), radius = 22.dp) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(tint.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                LIcon(icon, 20.dp, tint)
            }
            Spacer(Modifier.height(8.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (enabled) cs.onSurface else cs.onSurfaceVariant, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}

@Composable
private fun AddBar(ctx: Context, onScan: () -> Unit, onCreate: () -> Unit, onPanel: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val canTest = !AppState.testing && !AppState.connected && !AppState.busy && AppState.configs.isNotEmpty()
    Column(Modifier.fillMaxWidth().padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            tr("کانفیگ‌ها", "Configs") + " (${AppState.configs.size})",
            fontWeight = FontWeight.Bold, fontSize = 17.sp, color = cs.onBackground,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile("scan", tr("اسکن QR", "Scan QR"), Modifier.weight(1f), onClick = onScan)
            ActionTile("clipboard", tr("چسباندن", "Paste"), Modifier.weight(1f), onClick = { pasteFromClipboard(ctx) })
            ActionTile("zap", tr("تست پینگ", "Ping test"), Modifier.weight(1f), enabled = canTest, onClick = { Core.test(ctx, AppState.configs.toList()) })
        }
        if (!Edition.CUSTOMER) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile("plus", tr("ساخت کانفیگ", "Create"), Modifier.weight(1f), onClick = onCreate)
                ActionTile("database", tr("دریافت از پنل", "From panel"), Modifier.weight(1f), onClick = onPanel)
            }
        }
    }
}

@Composable
private fun EmptyCard(onScan: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Glass(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(54.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                LIcon("qr", 28.dp, cs.primary)
            }
            Spacer(Modifier.height(12.dp))
            Text(tr("هنوز کانفیگی ندارید", "No configs yet"), fontWeight = FontWeight.Bold, color = cs.onSurface)
            Spacer(Modifier.height(6.dp))
            Text(
                tr(
                    "QR یا لینک اشتراکی که از فروشنده گرفته‌اید را اسکن یا کپی کنید و «چسباندن» را بزنید. کانفیگ epx:// هم همین‌طور.",
                    "Scan the QR you got from your seller, or copy the subscription link or epx:// config and tap Paste.",
                ),
                fontSize = 13.sp, textAlign = TextAlign.Center, color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(EpicGradient).clickable(onClick = onScan).padding(horizontal = 22.dp, vertical = 10.dp),
            ) { Text(tr("اسکن QR", "Scan QR"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        }
    }
}

@Composable
private fun CfgCard(ctx: Context, c: Cfg, onEdit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val sel = AppState.selected == c.id
    val locked = AppState.connected || AppState.busy
    Glass(Modifier.fillMaxWidth(), radius = 24.dp, border = if (sel) cs.primary else null) {
        Column(
            Modifier
                .clickable(enabled = !locked) { AppState.selected = c.id; AppState.save(ctx) }
                .padding(14.dp),
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(if (sel) cs.primary.copy(alpha = 0.18f) else cs.surfaceVariant),
                    contentAlignment = Alignment.Center,
                ) { Text(c.badge, color = if (sel) cs.primary else cs.onSurfaceVariant, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurface)
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Chip(c.scan, cs.onSurfaceVariant)
                        if (c.loc.isNotEmpty()) Chip("${flagEmoji(c.loc)} ${c.loc}", Blue)
                        if (c.psiphon) Chip("Psiphon" + if (c.psiRegion.isNotEmpty()) " ${c.psiRegion}" else "", Purple)
                    }
                    if (!c.locked) {
                        Spacer(Modifier.height(3.dp))
                        Text("${c.host}:${c.port}", fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    val st = c.licId?.let { AppState.lic[it] }
                    val expShown = if (c.locked) (st?.exp ?: 0L) else c.exp
                    val nowSec = System.currentTimeMillis() / 1000
                    val d = if (expShown > 0) SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(expShown * 1000)) else ""
                    val left = if (expShown > nowSec) (expShown - nowSec + 86399) / 86400 else 0L
                    val info: String? = when {
                        c.locked && st == null -> tr("با اولین اتصال فعال می‌شود", "Activates on first connection")
                        c.locked && st?.status == "revoked" -> tr("ابطال شده", "Revoked")
                        c.locked && st?.status == "device" -> tr("روی دستگاه دیگری فعال است", "Active on another device")
                        c.locked && st?.status == "unknown" -> tr("نامعتبر", "Invalid")
                        expShown > 0 -> if (c.expired) tr("منقضی شده ($d)", "Expired ($d)") else tr("$left روز مانده · $d", "$left days left · $d")
                        c.locked -> tr("بدون انقضا", "No expiry")
                        else -> null
                    }
                    if (info != null) {
                        Spacer(Modifier.height(4.dp))
                        Text(info, fontSize = 12.sp, color = if (c.expired) Red else cs.onSurfaceVariant)
                    }
                }
                DelayPill(ctx, c)
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.End) {
                if (!c.locked) {
                    TextButton(onClick = onEdit, enabled = !locked && !AppState.testing) { Text(tr("ویرایش", "Edit"), fontSize = 12.sp) }
                    IconButton(onClick = { shareLink(ctx, c.raw) }, modifier = Modifier.size(36.dp)) { LIcon("share", 18.dp, cs.onSurfaceVariant) }
                }
                IconButton(
                    onClick = { AppState.remove(ctx, c.id) },
                    enabled = !locked && !AppState.testing, modifier = Modifier.size(36.dp),
                ) { LIcon("trash", 18.dp, if (locked) cs.onSurfaceVariant.copy(alpha = 0.4f) else Red) }
            }
        }
    }
}

@Composable
private fun DelayPill(ctx: Context, c: Cfg) {
    val cs = MaterialTheme.colorScheme
    if (AppState.testingId == c.id) {
        Box(Modifier.width(64.dp).height(32.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = cs.primary)
        }
        return
    }
    val (txt, col) = when {
        c.delay == 0 -> tr("تست", "Test") to cs.onSurfaceVariant
        c.delay < 0 -> tr("خطا", "Error") to Red
        c.delay < 800 -> "${c.delay} ms" to Green
        else -> "${c.delay} ms" to Amber
    }
    val canTest = !AppState.testing && !AppState.connected && !AppState.busy && !c.expired
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(col.copy(alpha = 0.15f))
            .clickable(enabled = canTest) { Core.test(ctx, listOf(c)) }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) { Text(txt, color = col, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
}

@Composable
private fun SettingsCard(ctx: Context) {
    val cs = MaterialTheme.colorScheme
    val locked = AppState.connected || AppState.busy || AppState.testing
    val sw = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Green)
    Glass(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LIcon("shield", 20.dp, cs.primary)
                Spacer(Modifier.width(8.dp))
                Text(tr("تنظیمات", "Settings"), fontWeight = FontWeight.Bold, color = cs.onSurface)
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("حالت VPN (کل گوشی)", "VPN mode (whole phone)"), fontSize = 14.sp, color = cs.onSurface)
                    Text(
                        tr("خاموش = فقط پراکسی SOCKS5 برای برنامه‌هایی مثل تلگرام یا v2rayNG", "Off = SOCKS5 proxy only, for apps like Telegram or v2rayNG"),
                        fontSize = 11.sp, color = cs.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = AppState.vpnMode, enabled = !locked, colors = sw,
                    onCheckedChange = { AppState.vpnMode = it; AppState.save(ctx) },
                )
            }
            if (!Edition.CUSTOMER) {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("اتصال مستقیم به آدرس لینک", "Connect straight to the link address"), fontSize = 14.sp, color = cs.onSurface)
                        Text(
                            tr("به‌جای اسکن، از همان آی‌پی و پورت لینک استفاده می‌شود", "Use the link's own IP and port instead of scanning"),
                            fontSize = 11.sp, color = cs.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Switch(
                        checked = AppState.usePeer, enabled = !locked, colors = sw,
                        onCheckedChange = { AppState.usePeer = it; AppState.save(ctx) },
                    )
                }
            }
        }
    }
}

package com.epicvpn.app

import android.content.Context
import android.provider.Settings
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.net.URLEncoder
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PublicKey
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Last answer of the panel for one license. status: active | expired | revoked | device | unknown */
data class LicState(val status: String, val exp: Long, val lastOk: Long)

/** Encrypted configs and license checks against the panel. */
object Lic {
    private const val GRACE_MS = 24L * 3600 * 1000   // how long an "active" answer is trusted offline

    private class Reply(val id: String, val status: String, val exp: Long, val ts: Long, val sig: String)

    /** Symmetric key that only decrypts config tokens. */
    private fun aesKey(): ByteArray? = try {
        Base64.decode(Secret.AES_KEY, Base64.DEFAULT).takeIf { it.size == 32 }
    } catch (e: Exception) {
        null
    }

    /** Public key that only verifies the panel's signature; the private half never leaves the server. */
    private fun pubKey(): PublicKey? = try {
        val der = Base64.decode(Secret.PUB_KEY, Base64.DEFAULT)
        KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(der))
    } catch (e: Exception) {
        null
    }

    /** epx://<base64url(iv12 | ciphertext | tag16)>, AES-256-GCM, AAD "epic1". */
    fun decrypt(token: String): JSONObject? {
        val k = aesKey() ?: return null
        return try {
            val raw = Base64.decode(
                token.trim().removePrefix("epx://"),
                Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP,
            )
            if (raw.size < 12 + 16 + 2) return null
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(k, "AES"), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            c.updateAAD("epic1".toByteArray())
            JSONObject(String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8))
        } catch (e: Exception) {
            null
        }
    }

    /** Human-readable reason why [token] could not be imported. */
    fun importProblem(token: String): String {
        if (!token.trim().startsWith("epx://")) {
            return "کانفیگ معتبر نیست. فقط کانفیگ‌هایی که با epx:// شروع می‌شوند پذیرفته می‌شوند."
        }
        if (aesKey() == null) {
            return "کلید رمزنگاری داخل این نسخه اپ خالی است. سکرت‌های اپ را در گیت‌هاب بررسی و اپ را دوباره بسازید."
        }
        return "این کانفیگ با کلید اپ باز نشد. یا کلید اپ با کلید پنل فرق دارد، یا کانفیگ ناقص کپی شده است."
    }

    private fun deviceId(ctx: Context): String {
        val aid = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "x"
        return MessageDigest.getInstance("SHA-256").digest("$aid|epic".toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    /** RSA-SHA256 verify; [sigB64] is standard base64 (not url-safe) from the panel. */
    private fun verify(pub: PublicKey, data: String, sigB64: String): Boolean = try {
        val sig = Signature.getInstance("SHA256withRSA")
        sig.initVerify(pub)
        sig.update(data.toByteArray())
        sig.verify(Base64.decode(sigB64, Base64.DEFAULT))
    } catch (e: Exception) {
        false
    }

    private fun save(ctx: Context, id: String, s: LicState) = ui {
        AppState.lic[id] = s
        AppState.saveLic(ctx)
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("lic", 0)

    /** One request to the panel, directly or through the local proxy. Throws on any network/format problem. */
    private fun fetch(ctx: Context, c: Cfg, url: String, viaProxy: Boolean, timeoutMs: Int): Reply {
        val body = "act=status&t=" + URLEncoder.encode(c.raw, "UTF-8") + "&dev=" + deviceId(ctx)
        val u = URL(url)
        val conn = (
            if (viaProxy) u.openConnection(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", Core.MAIN_PORT)))
            else u.openConnection()
            ) as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = timeoutMs
        conn.readTimeout = timeoutMs
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        conn.outputStream.use { it.write(body.toByteArray()) }
        if (conn.responseCode != 200) throw java.io.IOException("HTTP ${conn.responseCode}")
        val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
        return Reply(j.getString("id"), j.getString("status"), j.optLong("exp", 0L), j.getLong("ts"), j.getString("sig"))
    }

    /**
     * Asks the panel whether this config may be used. Returns null when allowed, otherwise a message.
     * [proxyUp]: the local proxy is running, so the panel can also be reached through the tunnel.
     * The way that worked last time is tried first (direct by default), then the other one.
     */
    fun check(ctx: Context, c: Cfg, proxyUp: Boolean): String? {
        val id = c.licId ?: return null
        val url = c.panelUrl ?: return "آدرس پنل داخل کانفیگ نیست."
        val pub = pubKey() ?: return "کلید تأیید در این نسخه اپ تنظیم نشده است."
        val now = System.currentTimeMillis()
        val last = prefs(ctx).getString("mode_$id", "direct")
        val modes = if (!proxyUp) listOf(false) else if (last == "proxy") listOf(true, false) else listOf(false, true)

        var reply: Reply? = null
        for ((i, viaProxy) in modes.withIndex()) {
            try {
                reply = fetch(ctx, c, url, viaProxy, if (i == 0 && modes.size > 1) 5000 else 8000)
                prefs(ctx).edit().putString("mode_$id", if (viaProxy) "proxy" else "direct").apply()
                break
            } catch (e: Exception) {
                // try the next way
            }
        }

        if (reply == null) {
            val s = AppState.lic[id]
            if (s != null && s.status == "active" && now - s.lastOk < GRACE_MS &&
                (s.exp == 0L || now / 1000 < s.exp)
            ) return null
            return "به پنل دسترسی پیدا نشد؛ اینترنت و آدرس پنل را بررسی کنید."
        }

        if (!verify(pub, "${reply.id}|${reply.status}|${reply.exp}|${reply.ts}", reply.sig) || reply.id != id) {
            return "پاسخ پنل معتبر نیست."
        }
        if (kotlin.math.abs(now / 1000 - reply.ts) > 86400) return "ساعت گوشی را درست کنید."
        save(ctx, id, LicState(reply.status, reply.exp, now))
        return when (reply.status) {
            "active" -> null
            "expired" -> "مدت این کانفیگ تمام شده است."
            "revoked" -> "این کانفیگ ابطال شده است."
            "device" -> "این کانفیگ روی دستگاه دیگری فعال شده است."
            else -> "این کانفیگ معتبر نیست."
        }
    }

    /** Silent background check of locked configs (updates the status shown on the cards). */
    fun refresh(ctx: Context, list: List<Cfg>) {
        val l = list.filter { it.locked }
        if (l.isEmpty()) return
        Thread { l.forEach { check(ctx, it, AppState.connected) } }.start()
    }
}

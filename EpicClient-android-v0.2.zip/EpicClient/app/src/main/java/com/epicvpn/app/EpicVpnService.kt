package com.epicvpn.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import hev.htproxy.TProxyService
import java.io.File

/**
 * Starts the VPN core (local SOCKS5 on 127.0.0.1:1819) and routes the whole phone into it
 * through a VPN interface + hev-socks5-tunnel (tun2socks). DNS is answered locally by hev (mapdns)
 * so every connection reaches it as a domain name over TCP.
 */
class EpicVpnService : VpnService() {
    private var proc: Process? = null
    private var tun: ParcelFileDescriptor? = null
    @Volatile private var generation = 0

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            generation++
            Thread {
                teardown()
                ui { AppState.message = "" }
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }.start()
            return START_NOT_STICKY
        }
        val cfg = AppState.configs.find { it.id == intent?.getStringExtra("id") }
        if (cfg == null) { stopSelf(); return START_NOT_STICKY }
        startForeground(1, notification("در حال اتصال به ${cfg.name}"))
        if (cfg.expired) {
            ui { AppState.message = "این کانفیگ منقضی شده است." }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val gen = ++generation
        teardown()
        ui { AppState.message = ""; AppState.busy = true; AppState.connected = false }
        Thread { run(cfg, gen) }.start()
        return START_NOT_STICKY
    }

    private fun run(cfg: Cfg, gen: Int) {
        try {
            val p = Core.start(this, cfg, Core.MAIN_PORT)
            proc = p
            if (!Core.waitReady(p, Core.MAIN_PORT, 90_000)) {
                if (gen == generation) fail("اتصال برقرار نشد. لاگ را ببینید.")
                return
            }
            if (gen != generation) return

            // Direct first (if the panel is reachable), otherwise through the local proxy.
            if (cfg.locked) {
                val err = Lic.check(this, cfg, true)
                if (gen != generation) return
                if (err != null) { fail(err); return }
                lastCheck = System.currentTimeMillis()
            }

            if (!AppState.vpnMode) {
                // proxy-only: just keep the local SOCKS5 proxy alive
                ui {
                    AppState.busy = false
                    AppState.connected = true
                    AppState.connectedAt = SystemClock.elapsedRealtime()
                    AppState.txBytes = 0
                    AppState.rxBytes = 0
                }
                getSystemService(NotificationManager::class.java).notify(1, notification("پراکسی فعال: 127.0.0.1:${Core.MAIN_PORT}"))
                while (gen == generation && p.isAlive && !cfg.expired) {
                    val e = licenseCheck(cfg)
                    if (e != null) { if (gen == generation) fail(e); return }
                    Thread.sleep(1000)
                }
                if (gen == generation) fail(if (cfg.expired) "کانفیگ منقضی شد." else "اتصال قطع شد.")
                return
            }

            val builder = Builder()
                .setSession("Epic")
                .setMtu(MTU)
                .setMetered(false)
                .addAddress("198.18.0.1", 30)
                .addAddress("fc00::1", 128)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                .addDnsServer("198.18.0.2")
                .addDisallowedApplication(packageName) // the core's own sockets must bypass the VPN
            val fd = builder.establish()
            if (fd == null) { if (gen == generation) fail("مجوز VPN داده نشد."); return }
            tun = fd

            val conf = File(filesDir, "hev.yml")
            conf.writeText(
                """
                tunnel:
                  mtu: $MTU
                  ipv4: 198.18.0.1
                  ipv6: 'fc00::1'
                socks5:
                  port: ${Core.MAIN_PORT}
                  address: 127.0.0.1
                  udp: 'udp'
                mapdns:
                  address: 198.18.0.2
                  port: 53
                  network: 100.64.0.0
                  netmask: 255.192.0.0
                  cache-size: 10000
                misc:
                  task-stack-size: 24576
                  connect-timeout: 8000
                  log-level: warn
                """.trimIndent() + "\n"
            )
            if (!TProxyService.TProxyStartService(conf.absolutePath, fd.fd)) {
                if (gen == generation) fail("راه‌اندازی tun2socks ناموفق بود.")
                return
            }

            ui {
                AppState.busy = false
                AppState.connected = true
                AppState.connectedAt = SystemClock.elapsedRealtime()
                AppState.txBytes = 0
                AppState.rxBytes = 0
            }
            getSystemService(NotificationManager::class.java).notify(1, notification("متصل: ${cfg.name}"))

            while (gen == generation && p.isAlive && !cfg.expired) {
                val e = licenseCheck(cfg)
                if (e != null) { if (gen == generation) fail(e); return }
                try {
                    val s = TProxyService.TProxyGetStats()
                    if (s != null && s.size >= 4) ui { AppState.txBytes = s[1]; AppState.rxBytes = s[3] }
                } catch (_: Throwable) {}
                Thread.sleep(1000)
            }
            if (gen == generation) fail(if (cfg.expired) "کانفیگ منقضی شد." else "اتصال قطع شد.")
        } catch (t: Throwable) {
            AppState.log("خطا: ${t.message}")
            if (gen == generation) fail("خطا: ${t.message}")
        }
    }

    @Volatile private var lastCheck = 0L

    /** Re-checks the license every 5 minutes while connected (through the proxy). Null = still allowed. */
    private fun licenseCheck(cfg: Cfg): String? {
        if (!cfg.locked) return null
        val now = System.currentTimeMillis()
        if (now - lastCheck < 300_000) return null
        lastCheck = now
        return Lic.check(this, cfg, true)
    }

    private fun fail(msg: String) {
        teardown()
        ui { AppState.message = msg }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    @Synchronized
    private fun teardown() {
        try { TProxyService.TProxyStopService() } catch (_: Throwable) {}
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
        Core.kill(proc)
        proc = null
        ui { AppState.busy = false; AppState.connected = false }
    }

    override fun onRevoke() {
        generation++
        teardown()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        generation++
        teardown()
        super.onDestroy()
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("epic", "Epic", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "epic")
            .setContentTitle("Epic")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.epicvpn.app.STOP"
        private const val MTU = 1500
    }
}

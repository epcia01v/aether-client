package com.epicvpn.app

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.TimeUnit

/** Runs the VPN core binary (shipped as libcore.so) and measures real delay through it. */
object Core {
    const val MAIN_PORT = 1819
    private const val TEST_PORT = 1830

    fun args(ctx: Context, c: Cfg, port: Int): List<String> {
        val a = mutableListOf(File(ctx.applicationInfo.nativeLibraryDir, "libcore.so").absolutePath)
        a += when (c.protocol) {
            "masque" -> "--masque"
            "gool" -> "--gool"
            "mim" -> "--mim"
            else -> "--wg"
        }
        a += listOf("--scan", c.scan)
        a += listOf("--ip", c.ip)
        a += "--quick-reconnect"
        a += listOf("--bind", "127.0.0.1:$port")
        a += listOf("--config", File(ctx.filesDir, "core.toml").absolutePath)
        if (AppState.usePeer && !c.locked) a += listOf("--peer", "${c.host}:${c.port}")
        return a
    }

    fun start(ctx: Context, c: Cfg, port: Int): Process {
        val cmd = args(ctx, c, port)
        if (!c.locked) AppState.log("> " + cmd.drop(1).joinToString(" "))
        val pb = ProcessBuilder(cmd).directory(ctx.filesDir).redirectErrorStream(true)
        pb.environment()["HOME"] = ctx.filesDir.path
        val p = pb.start()
        Thread {
            try {
                p.inputStream.bufferedReader().forEachLine {
                    AppState.log(it.replace(Regex("\u001B\\[[;\\d]*m"), "").replace(Regex("aether", RegexOption.IGNORE_CASE), "core"))
                }
            } catch (_: Exception) {}
        }.start()
        return p
    }

    fun kill(p: Process?) {
        if (p == null) return
        p.destroy()
        try { p.waitFor(2, TimeUnit.SECONDS) } catch (_: Exception) {}
        if (p.isAlive) p.destroyForcibly()
    }

    /** One HTTPS request through the local SOCKS5 proxy. Returns milliseconds, or -1 on failure. */
    fun probe(port: Int): Int {
        val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", port))
        val t0 = System.nanoTime()
        return try {
            val c = URL("https://1.1.1.1/cdn-cgi/trace").openConnection(proxy) as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.instanceFollowRedirects = false
            c.responseCode
            c.disconnect()
            maxOf(1, ((System.nanoTime() - t0) / 1_000_000).toInt())
        } catch (e: Exception) {
            -1
        }
    }

    fun waitReady(p: Process, port: Int, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (!p.isAlive) return false
            if (probe(port) >= 0) return true
            Thread.sleep(500)
        }
        return false
    }

    /** Tests the given configs one by one: the core runs once per config and one real request is timed. */
    fun test(ctx: Context, all: List<Cfg>) {
        val list = all.filter { !it.expired }
        if (AppState.testing || AppState.connected || AppState.busy || list.isEmpty()) return
        ui { AppState.testing = true }
        Thread {
            try {
                for (c in list) {
                    ui { AppState.testingId = c.id }
                    var p: Process? = null
                    var d = -1
                    try {
                        p = start(ctx, c, TEST_PORT)
                        if (waitReady(p, TEST_PORT, 45_000)) d = probe(TEST_PORT)
                    } catch (e: Exception) {
                        AppState.log("خطا: ${e.message}")
                    } finally {
                        kill(p)
                    }
                    AppState.setDelay(c.id, d)
                    Thread.sleep(500)
                }
            } finally {
                ui { AppState.testing = false; AppState.testingId = null }
            }
        }.start()
    }
}

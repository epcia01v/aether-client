package com.epicvpn.app

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.TimeUnit

/** Runs the VPN core binary (shipped as libcore.so) and measures real delay through it. */
object Core {
    const val MAIN_PORT = 1819
    private const val TEST_PORT = 1830

    /**
     * [forcePeer]: dial c.host:c.port directly with no scan (fast, ArasClient-style, but only as good as
     * that one saved endpoint); when false, scan normally. Callers try forcePeer first and fall back to a
     * normal scan if it doesn't come up in time, so a stale saved endpoint never blocks the connection.
     */
    /** Port the app must talk to: with the Psiphon chain, aether serves the Psiphon exit on port+2 (WARP stays on [port]). */
    fun proxyPort(c: Cfg, port: Int): Int = if (c.psiphon) port + 2 else port

    /** How long to wait for the proxy to come up; Psiphon needs to bootstrap on top of the tunnel. */
    fun readyTimeout(c: Cfg, normalMs: Long): Long = if (c.psiphon) maxOf(normalMs, 200_000L) else normalMs

    fun args(ctx: Context, c: Cfg, port: Int, forcePeer: Boolean): List<String> {
        val a = mutableListOf(File(ctx.applicationInfo.nativeLibraryDir, "libcore.so").absolutePath)
        a += when (c.protocol) {
            "masque" -> "--masque"
            "gool" -> "--gool"
            "mim" -> "--mim"
            else -> "--wg"
        }
        a += listOf("--scan", c.scan)
        a += listOf("--ip", c.ip)
        // --exit-loc is NOT used: it refuses and re-scans until that exact country shows up, so if this
        // network never reaches it, the proxy never starts at all (tested and confirmed with the real core).
        // c.loc, when set, is shown as a hint only; AppState.detectedLoc below is the real, live exit country.
        if (c.psiphon) {
            // Chain: aether -> WARP -> Psiphon -> internet. psiphon-tunnel-core ships as libpsiphon.so
            // (same folder as libcore.so) because Android only lets us execute files from nativeLibraryDir.
            a += "--psiphon"
            a += listOf("--psiphon-bin", File(ctx.applicationInfo.nativeLibraryDir, "libpsiphon.so").absolutePath)
            a += listOf("--psiphon-bind", "127.0.0.1:${proxyPort(c, port)}")
            if (c.psiRegion.length == 2) a += listOf("--psiphon-region", c.psiRegion)
        }
        a += "--quick-reconnect"
        a += listOf("--bind", "127.0.0.1:$port")
        a += listOf("--config", File(ctx.filesDir, "core.toml").absolutePath)
        val hasPeer = c.host.isNotEmpty() && c.port > 0
        if (forcePeer && hasPeer) a += listOf("--peer", "${c.host}:${c.port}")
        else if (AppState.usePeer && !c.locked && hasPeer) a += listOf("--peer", "${c.host}:${c.port}")
        return a
    }

    /** True only when this config has a saved endpoint worth trying directly before falling back to a scan. */
    fun hasSavedPeer(c: Cfg): Boolean = c.locked && c.host.isNotEmpty() && c.port > 0

    fun start(ctx: Context, c: Cfg, port: Int, forcePeer: Boolean = false): Process {
        val cmd = args(ctx, c, port, forcePeer)
        if (!c.locked) AppState.log("> " + cmd.drop(1).joinToString(" "))
        val pb = ProcessBuilder(cmd).directory(ctx.filesDir).redirectErrorStream(true)
        pb.environment()["HOME"] = ctx.filesDir.path
        val p = pb.start()
        Thread {
            try {
                p.inputStream.bufferedReader().forEachLine {
                    val clean = it.replace(Regex("\u001B\\[[;\\d]*m"), "").replace(Regex("aether", RegexOption.IGNORE_CASE), "core")
                AppState.log(clean)
                // e.g. "wireguard exit: 104.28.214.161, IR via GYD, 390ms to cloudflare" -> country code "IR"
                Regex(",\\s*([A-Z]{2})\\s+via\\s").find(clean)?.groupValues?.get(1)?.let { cc -> ui { AppState.detectedLoc = cc } }
                }
            } catch (_: Exception) {}
        }.start()
        return p
    }

    fun kill(p: Process?) {
        if (p == null) return
        p.destroy()
        try { p.waitFor(2, TimeUnit.SECONDS) } catch (_: Exception) {}
        if (p.isAlive) p.destroyForcibly()
    }

    /** One HTTPS request through the local SOCKS5 proxy. Returns milliseconds, or -1 on failure. */
    fun probe(port: Int): Int {
        val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", port))
        val t0 = System.nanoTime()
        return try {
            val c = URL("https://1.1.1.1/cdn-cgi/trace").openConnection(proxy) as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.instanceFollowRedirects = false
            c.responseCode
            c.disconnect()
            maxOf(1, ((System.nanoTime() - t0) / 1_000_000).toInt())
        } catch (e: Exception) {
            -1
        }
    }

    fun waitReady(p: Process, port: Int, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (!p.isAlive) return false
            if (probe(port) >= 0) return true
            Thread.sleep(500)
        }
        return false
    }

    /** Tests the given configs one by one: the core runs once per config and one real request is timed. */
    fun test(ctx: Context, all: List<Cfg>) {
        val list = all.filter { !it.expired }
        if (AppState.testing || AppState.connected || AppState.busy || list.isEmpty()) return
        ui { AppState.testing = true }
        Thread {
            try {
                for (c in list) {
                    ui { AppState.testingId = c.id }
                    var p: Process? = null
                    var d = -1
                    try {
                        p = start(ctx, c, TEST_PORT)
                        if (waitReady(p, proxyPort(c, TEST_PORT), readyTimeout(c, 45_000))) d = probe(proxyPort(c, TEST_PORT))
                    } catch (e: Exception) {
                        AppState.log("خطا: ${e.message}")
                    } finally {
                        kill(p)
                    }
                    AppState.setDelay(c.id, d)
                    Thread.sleep(500)
                }
            } finally {
                ui { AppState.testing = false; AppState.testingId = null }
            }
        }.start()
    }
}

package com.epicvpn.app

/** CUSTOMER = true: the app can only import encrypted epx:// configs from the seller (no creating/editing). */
object Edition {
    const val CUSTOMER = true
}

# Aether Client (Android) — v0.2

کلاینت VPN برای لینک‌های `aether://`: وارد کردن، لیست، تست پینگ واقعی، اتصال یک‌لمسی (VPN کل گوشی).

## چطور کار می‌کند
- هسته Aether (https://github.com/CluvexStudio/Aether) به‌صورت پراکسی SOCKS5 روی `127.0.0.1:1819` اجرا می‌شود.
- `VpnService` + tun2socks (hev-socks5-tunnel، لایسنس MIT) ترافیک کل گوشی را به همان پراکسی می‌دهد. DNS هم محلی پاسخ داده می‌شود (mapdns).
- خود اپ از VPN مستثنی است تا ترافیک هسته در حلقه نیفتد.

## ساخت APK
فایل zip را در ریشه مخزن بگذارید (با همان نام AetherClient-android-v0.1.zip) و workflow *Build APK* را اجرا کنید. هسته Aether را workflow از ریلیز رسمی می‌گیرد و checksum را چک می‌کند.

## یادداشت‌ها
- حداقل اندروید ۱۰.
- معنی `host:port` داخل لینک مستند نیست؛ به‌طور پیش‌فرض اسکن Aether مسیر را پیدا می‌کند. سوییچ «اتصال مستقیم» از `--peer` استفاده می‌کند.
- لایسنس: AGPL-3.0 (مطابق هسته Aether). tun2socks: MIT، https://github.com/heiher/hev-socks5-tunnel

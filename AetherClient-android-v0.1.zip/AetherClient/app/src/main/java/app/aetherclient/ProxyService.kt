package app.aetherclient

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder

class ProxyService : Service() {
    private var proc: Process? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            Core.kill(proc); proc = null
            ui { AppState.connected = false; AppState.busy = false; AppState.status = "قطع" }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val cfg = AppState.configs.find { it.id == intent?.getStringExtra("id") }
        if (cfg == null) { stopSelf(); return START_NOT_STICKY }
        startForeground(1, notification("در حال اتصال به ${cfg.name}"))
        ui { AppState.busy = true; AppState.status = "در حال اتصال…" }
        Thread {
            Core.kill(proc)
            try {
                val p = Core.start(this, cfg, Core.MAIN_PORT)
                proc = p
                if (Core.waitReady(p, Core.MAIN_PORT, 90_000)) {
                    ui {
                        AppState.busy = false; AppState.connected = true
                        AppState.status = "متصل • SOCKS5 127.0.0.1:${Core.MAIN_PORT}"
                    }
                    getSystemService(NotificationManager::class.java).notify(1, notification("متصل: ${cfg.name}"))
                    p.waitFor()
                }
            } catch (e: Exception) {
                AppState.log("خطا: ${e.message}")
            }
            ui { AppState.connected = false; AppState.busy = false; AppState.status = "قطع" }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        Core.kill(proc)
        super.onDestroy()
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("aether", "Aether", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "aether")
            .setContentTitle("Aether Client")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .build()
    }
}

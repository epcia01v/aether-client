package app.aetherclient

/** Placeholder. The GitHub workflow overwrites this file with the real key (secret AETHER_KEY). */
object Secret { const val KEY = "" }

package app.aetherclient

/** CUSTOMER = true: the app can only import encrypted aethx:// configs from the seller (no creating/editing). */
object Edition {
    const val CUSTOMER = true
}

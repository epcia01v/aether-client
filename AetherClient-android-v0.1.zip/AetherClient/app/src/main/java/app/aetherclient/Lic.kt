package app.aetherclient

import android.content.Context
import android.provider.Settings
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Last answer of the panel for one license. status: active | expired | revoked | device | unknown */
data class LicState(val status: String, val exp: Long, val lastOk: Long)

/** Encrypted configs (aethx://) and license checks against the panel. */
object Lic {
    private const val GRACE_MS = 24L * 3600 * 1000   // how long an "active" answer is trusted offline

    private fun key(): ByteArray? = try {
        Base64.decode(Secret.KEY, Base64.DEFAULT).takeIf { it.size == 32 }
    } catch (e: Exception) {
        null
    }

    /** aethx://<base64url(iv12 | ciphertext | tag16)>, AES-256-GCM, AAD "aethx1". */
    fun decrypt(token: String): JSONObject? {
        val k = key() ?: return null
        return try {
            val raw = Base64.decode(
                token.trim().removePrefix("aethx://"),
                Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP,
            )
            if (raw.size < 12 + 16 + 2) return null
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(k, "AES"), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            c.updateAAD("aethx1".toByteArray())
            JSONObject(String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8))
        } catch (e: Exception) {
            null
        }
    }

    private fun deviceId(ctx: Context): String {
        val aid = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "x"
        return MessageDigest.getInstance("SHA-256").digest("$aid|aether".toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    private fun hmacHex(k: ByteArray, s: String): String {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(k, "HmacSHA256"))
        return m.doFinal(s.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    private fun save(ctx: Context, id: String, s: LicState) = ui {
        AppState.lic[id] = s
        AppState.saveLic(ctx)
    }

    /**
     * Asks the panel whether this config may be used. Returns null when allowed, otherwise a message.
     * [viaProxy] sends the request through the local Aether proxy (used while connected).
     */
    fun check(ctx: Context, c: Cfg, viaProxy: Boolean): String? {
        val id = c.licId ?: return null
        val url = c.panelUrl ?: return "آدرس پنل داخل کانفیگ نیست."
        val k = key() ?: return "کلید رمزنگاری در این نسخه اپ تنظیم نشده است."
        val now = System.currentTimeMillis()
        try {
            val body = "act=status&t=" + URLEncoder.encode(c.raw, "UTF-8") + "&dev=" + deviceId(ctx)
            val u = URL(url)
            val conn = (if (viaProxy) u.openConnection(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", Core.MAIN_PORT)))
            else u.openConnection()) as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.outputStream.use { it.write(body.toByteArray()) }
            if (conn.responseCode != 200) throw java.io.IOException("HTTP ${conn.responseCode}")
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val rid = j.getString("id")
            val status = j.getString("status")
            val exp = j.optLong("exp", 0L)
            val ts = j.getLong("ts")
            val sig = j.getString("sig")
            val want = hmacHex(k, "$rid|$status|$exp|$ts")
            if (!MessageDigest.isEqual(want.toByteArray(), sig.toByteArray()) || rid != id) {
                return "پاسخ پنل معتبر نیست."
            }
            if (kotlin.math.abs(now / 1000 - ts) > 86400) return "ساعت گوشی را درست کنید."
            save(ctx, id, LicState(status, exp, now))
            return when (status) {
                "active" -> null
                "expired" -> "مدت این کانفیگ تمام شده است."
                "revoked" -> "این کانفیگ ابطال شده است."
                "device" -> "این کانفیگ روی دستگاه دیگری فعال شده است."
                else -> "این کانفیگ معتبر نیست."
            }
        } catch (e: Exception) {
            val s = AppState.lic[id]
            if (s != null && s.status == "active" && now - s.lastOk < GRACE_MS &&
                (s.exp == 0L || now / 1000 < s.exp)
            ) return null
            return "برای تأیید مجوز باید به پنل دسترسی داشته باشید."
        }
    }

    /** Silent background check of locked configs (updates the status shown on the cards). */
    fun refresh(ctx: Context, list: List<Cfg>) {
        val l = list.filter { it.locked }
        if (l.isEmpty()) return
        Thread { l.forEach { check(ctx, it, AppState.connected) } }.start()
    }
}

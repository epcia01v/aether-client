package app.aetherclient

import android.content.Context
import android.provider.Settings
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Last answer of the panel for one license. status: active | expired | revoked | device | unknown */
data class LicState(val status: String, val exp: Long, val lastOk: Long)

/** Encrypted configs (aethx) and license checks against the panel. */
object Lic {
    private const val GRACE_MS = 24L * 3600 * 1000   // how long an "active" answer is trusted offline

    private class Reply(val id: String, val status: String, val exp: Long, val ts: Long, val sig: String)

    private fun key(): ByteArray? = try {
        Base64.decode(Secret.KEY, Base64.DEFAULT).takeIf { it.size == 32 }
    } catch (e: Exception) {
        null
    }

    /** aethx://<base64url(iv12 | ciphertext | tag16)>, AES-256-GCM, AAD "aethx1". */
    fun decrypt(token: String): JSONObject? {
        val k = key() ?: return null
        return try {
            val raw = Base64.decode(
                token.trim().removePrefix("aethx://"),
                Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP,
            )
            if (raw.size < 12 + 16 + 2) return null
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(k, "AES"), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            c.updateAAD("aethx1".toByteArray())
            JSONObject(String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8))
        } catch (e: Exception) {
            null
        }
    }

    private fun deviceId(ctx: Context): String {
        val aid = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "x"
        return MessageDigest.getInstance("SHA-256").digest("$aid|aether".toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    private fun hmacHex(k: ByteArray, s: String): String {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(k, "HmacSHA256"))
        return m.doFinal(s.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    private fun save(ctx: Context, id: String, s: LicState) = ui {
        AppState.lic[id] = s
        AppState.saveLic(ctx)
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("lic", 0)

    /** One request to the panel, directly or through the local Aether proxy. Throws on any network/format problem. */
    private fun fetch(ctx: Context, c: Cfg, url: String, viaProxy: Boolean, timeoutMs: Int): Reply {
        val body = "act=status&t=" + URLEncoder.encode(c.raw, "UTF-8") + "&dev=" + deviceId(ctx)
        val u = URL(url)
        val conn = (
            if (viaProxy) u.openConnection(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", Core.MAIN_PORT)))
            else u.openConnection()
            ) as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = timeoutMs
        conn.readTimeout = timeoutMs
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        conn.outputStream.use { it.write(body.toByteArray()) }
        if (conn.responseCode != 200) throw java.io.IOException("HTTP ${conn.responseCode}")
        val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
        return Reply(j.getString("id"), j.getString("status"), j.optLong("exp", 0L), j.getLong("ts"), j.getString("sig"))
    }

    /**
     * Asks the panel whether this config may be used. Returns null when allowed, otherwise a message.
     * [proxyUp]: the local Aether proxy is running, so the panel can also be reached through the tunnel.
     * The way that worked last time is tried first (direct by default), then the other one.
     */
    fun check(ctx: Context, c: Cfg, proxyUp: Boolean): String? {
        val id = c.licId ?: return null
        val url = c.panelUrl ?: return "آدرس پنل داخل کانفیگ نیست."
        val k = key() ?: return "کلید رمزنگاری در این نسخه اپ تنظیم نشده است."
        val now = System.currentTimeMillis()
        val last = prefs(ctx).getString("mode_$id", "direct")
        val modes = if (!proxyUp) listOf(false) else if (last == "proxy") listOf(true, false) else listOf(false, true)

        var reply: Reply? = null
        for ((i, viaProxy) in modes.withIndex()) {
            try {
                reply = fetch(ctx, c, url, viaProxy, if (i == 0 && modes.size > 1) 5000 else 8000)
                prefs(ctx).edit().putString("mode_$id", if (viaProxy) "proxy" else "direct").apply()
                break
            } catch (e: Exception) {
                // try the next way
            }
        }

        if (reply == null) {
            val s = AppState.lic[id]
            if (s != null && s.status == "active" && now - s.lastOk < GRACE_MS &&
                (s.exp == 0L || now / 1000 < s.exp)
            ) return null
            return "به پنل دسترسی پیدا نشد؛ اینترنت و آدرس پنل را بررسی کنید."
        }

        val want = hmacHex(k, "${reply.id}|${reply.status}|${reply.exp}|${reply.ts}")
        if (!MessageDigest.isEqual(want.toByteArray(), reply.sig.toByteArray()) || reply.id != id) {
            return "پاسخ پنل معتبر نیست."
        }
        if (kotlin.math.abs(now / 1000 - reply.ts) > 86400) return "ساعت گوشی را درست کنید."
        save(ctx, id, LicState(reply.status, reply.exp, now))
        return when (reply.status) {
            "active" -> null
            "expired" -> "مدت این کانفیگ تمام شده است."
            "revoked" -> "این کانفیگ ابطال شده است."
            "device" -> "این کانفیگ روی دستگاه دیگری فعال شده است."
            else -> "این کانفیگ معتبر نیست."
        }
    }

    /** Silent background check of locked configs (updates the status shown on the cards). */
    fun refresh(ctx: Context, list: List<Cfg>) {
        val l = list.filter { it.locked }
        if (l.isEmpty()) return
        Thread { l.forEach { check(ctx, it, AppState.connected) } }.start()
    }
}

package app.aetherclient

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.net.URI
import java.net.URLDecoder

/** delay: 0 = not tested, -1 = failed, >0 = milliseconds */
data class Cfg(
    val raw: String,
    val name: String,
    val host: String,
    val port: Int,
    val protocol: String,
    val scan: String,
    val ip: String,
    val delay: Int = 0,
) {
    val id: String get() = raw
    val badge: String
        get() = when (protocol) {
            "masque" -> "MQ"
            "gool" -> "GOOL"
            "mim" -> "MIM"
            else -> "WG"
        }
}

fun parseLink(s: String): Cfg? {
    val t = s.trim()
    if (!t.startsWith("aether://")) return null
    return try {
        val u = URI(t)
        val host = u.host ?: return null
        val port = if (u.port > 0) u.port else return null
        val q = (u.rawQuery ?: "").split("&")
            .filter { "=" in it }
            .associate { it.substringBefore("=") to URLDecoder.decode(it.substringAfter("="), "UTF-8") }
        val name = u.rawFragment?.let { URLDecoder.decode(it, "UTF-8") }?.takeIf { it.isNotBlank() }
            ?: "$host:$port"
        val ip = when (q["ip"]?.lowercase()) {
            "4", "v4", "ipv4" -> "v4"
            "6", "v6", "ipv6" -> "v6"
            else -> "both"
        }
        Cfg(
            raw = t, name = name, host = host, port = port,
            protocol = q["protocol"]?.lowercase() ?: "wg",
            scan = q["scan"]?.lowercase() ?: "balanced",
            ip = ip,
        )
    } catch (e: Exception) {
        null
    }
}

private val mainHandler = Handler(Looper.getMainLooper())
fun ui(f: () -> Unit) { mainHandler.post(f) }

object AppState {
    val configs = mutableStateListOf<Cfg>()
    val log = mutableStateListOf<String>()
    var selected by mutableStateOf<String?>(null)
    var connected by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var message by mutableStateOf("")
    var testing by mutableStateOf(false)
    var testingId by mutableStateOf<String?>(null)
    var usePeer by mutableStateOf(false)
    var vpnMode by mutableStateOf(true)
    var showLog by mutableStateOf(false)
    var connectedAt by mutableStateOf(0L)
    var txBytes by mutableStateOf(0L)
    var rxBytes by mutableStateOf(0L)

    /** 0 = off, 1 = connecting, 2 = connected */
    val state: Int get() = if (connected) 2 else if (busy) 1 else 0

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences("aether", 0)
        configs.clear()
        sp.getString("links", "")!!.split("\n").mapNotNull { parseLink(it) }.forEach { configs.add(it) }
        selected = sp.getString("sel", null)?.takeIf { s -> configs.any { it.id == s } } ?: configs.firstOrNull()?.id
        usePeer = sp.getBoolean("peer", false)
        vpnMode = sp.getBoolean("vpn", true)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("aether", 0).edit()
            .putString("links", configs.joinToString("\n") { it.raw })
            .putString("sel", selected)
            .putBoolean("peer", usePeer)
            .putBoolean("vpn", vpnMode)
            .apply()
    }

    fun addLinks(ctx: Context, text: String): Int {
        var n = 0
        text.split(Regex("\\s+")).mapNotNull { parseLink(it) }.forEach { c ->
            if (configs.none { it.id == c.id }) { configs.add(c); n++ }
        }
        if (selected == null) selected = configs.firstOrNull()?.id
        save(ctx)
        return n
    }

    fun remove(ctx: Context, id: String) {
        configs.removeAll { it.id == id }
        if (selected == id) selected = configs.firstOrNull()?.id
        save(ctx)
    }

    fun setDelay(id: String, d: Int) = ui {
        val i = configs.indexOfFirst { it.id == id }
        if (i >= 0) configs[i] = configs[i].copy(delay = d)
    }

    fun log(line: String) = ui {
        log.add(line)
        while (log.size > 200) log.removeAt(0)
    }
}

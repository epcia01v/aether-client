package app.aetherclient

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppState.load(this)
        Lic.refresh(this, AppState.configs.toList())
        handle(intent)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { App() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val d = i?.dataString ?: return
        val n = AppState.addLinks(this, d)
        Toast.makeText(this, if (n > 0) "کانفیگ اضافه شد" else "لینک معتبر نبود یا تکراری بود", Toast.LENGTH_SHORT).show()
    }
}

// ---------------------------------------------------------------- theme

private val Green = Color(0xFF22C55E)
private val Amber = Color(0xFFF59E0B)
private val Red = Color(0xFFEF4444)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF2DD4BF),
    onPrimary = Color(0xFF00382F),
    primaryContainer = Color(0xFF12353A),
    onPrimaryContainer = Color(0xFFD2FBF4),
    background = Color(0xFF0B1220),
    onBackground = Color(0xFFE6EDF7),
    surface = Color(0xFF121B2E),
    onSurface = Color(0xFFE6EDF7),
    surfaceVariant = Color(0xFF1B2742),
    onSurfaceVariant = Color(0xFF9FB0C8),
    outline = Color(0xFF2A3A5C),
    error = Color(0xFFFF6B6B),
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0F9D8F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7F5F0),
    onPrimaryContainer = Color(0xFF053B35),
    background = Color(0xFFF3F6FB),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE6ECF6),
    onSurfaceVariant = Color(0xFF52627A),
    outline = Color(0xFFD3DCE9),
    error = Color(0xFFD93025),
)

@Composable
fun App() {
    val scheme: ColorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Home() }
        }
    }
}

// ---------------------------------------------------------------- helpers

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

private fun startVpn(ctx: Context) {
    val id = AppState.selected ?: return
    ctx.startForegroundService(Intent(ctx, AetherVpnService::class.java).putExtra("id", id))
}

private fun stopVpn(ctx: Context) {
    ctx.startService(Intent(ctx, AetherVpnService::class.java).setAction(AetherVpnService.ACTION_STOP))
}

private fun pasteFromClipboard(ctx: Context) {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
    val n = AppState.addLinks(ctx, t)
    toast(ctx, if (n > 0) "$n کانفیگ اضافه شد" else "لینک aether:// در کلیپ‌بورد پیدا نشد")
}

private fun shareLink(ctx: Context, link: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, link)
    ctx.startActivity(Intent.createChooser(i, "اشتراک‌گذاری کانفیگ"))
}

private fun fmtBytes(b: Long): String {
    val units = arrayOf("B", "KB", "MB", "GB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return if (i == 0) "$b B" else String.format(Locale.US, "%.1f %s", v, units[i])
}

private fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}

// ---------------------------------------------------------------- dialogs state

private sealed interface Dlg {
    object Create : Dlg
    class Edit(val cfg: Cfg) : Dlg
    object Panel : Dlg
}

private class Form(
    name: String = "",
    protocol: String = "wg",
    scan: String = "balanced",
    ip: String = "both",
    endpoint: String = "",
    unit: String = "none",
    amount: String = "1",
    count: String = "5",
) {
    var name by mutableStateOf(name)
    var protocol by mutableStateOf(protocol)
    var scan by mutableStateOf(scan)
    var ip by mutableStateOf(ip)
    var endpoint by mutableStateOf(endpoint)
    var unit by mutableStateOf(unit)
    var amount by mutableStateOf(amount)
    var count by mutableStateOf(count)
}

private fun formOf(c: Cfg) = Form(
    name = c.name, protocol = c.protocol, scan = c.scan,
    ip = when (c.ip) { "v4" -> "4"; "v6" -> "6"; else -> "both" },
    endpoint = "${c.host}:${c.port}",
    unit = if (c.exp > 0) "keep" else "none",
)

private val PROTOCOLS = listOf("wg" to "WireGuard", "masque" to "MASQUE", "gool" to "Gool")
private val SCANS = listOf("turbo" to "turbo", "balanced" to "balanced", "thorough" to "thorough", "verified" to "verified", "ironclad" to "ironclad")
private val IPS = listOf("both" to "هر دو", "4" to "IPv4", "6" to "IPv6")

@Composable
private fun Choice(label: String, options: List<Pair<String, String>>, value: String, onChange: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(label, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (k, t) ->
            val sel = k == value
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) cs.primary else cs.surfaceVariant)
                    .clickable { onChange(k) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(t, fontSize = 13.sp, color = if (sel) cs.onPrimary else cs.onSurface) }
        }
    }
}

@Composable
private fun FormFields(f: Form, showName: Boolean, showEndpoint: Boolean, canKeep: Boolean) {
    val ltr = TextStyle(textDirection = TextDirection.Ltr)
    if (showName) {
        OutlinedTextField(
            value = f.name, onValueChange = { f.name = it }, singleLine = true,
            label = { Text("نام کانفیگ") }, modifier = Modifier.fillMaxWidth(),
        )
    }
    if (showEndpoint) {
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = f.endpoint, onValueChange = { f.endpoint = it }, singleLine = true, textStyle = ltr,
            label = { Text("آدرس:پورت (خالی = تصادفی)") }, modifier = Modifier.fillMaxWidth(),
        )
        TextButton(onClick = { f.endpoint = Gen.randomEndpoint() }) { Text("آدرس تصادفی جدید") }
    }
    Choice("پروتکل", PROTOCOLS, f.protocol) { f.protocol = it }
    Choice("حالت اسکن", SCANS, f.scan) { f.scan = it }
    Choice("نسخه IP", IPS, f.ip) { f.ip = it }
    val units = buildList<Pair<String, String>> {
        add("none" to "بدون انقضا"); add("hour" to "ساعت"); add("day" to "روز")
        if (canKeep) add("keep" to "حفظ انقضای فعلی")
    }
    Choice("مدت اعتبار", units, f.unit) { f.unit = it }
    if (f.unit == "hour" || f.unit == "day") {
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = f.amount, onValueChange = { f.amount = it.filter(Char::isDigit).take(4) }, singleLine = true,
            label = { Text(if (f.unit == "hour") "چند ساعت؟" else "چند روز؟") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun CfgDialog(ctx: Context, existing: Cfg?, onClose: () -> Unit) {
    val form = remember { if (existing == null) Form(name = Gen.randomName("aether-"), endpoint = Gen.randomEndpoint()) else formOf(existing) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (existing == null) "ساخت کانفیگ" else "ویرایش کانفیگ") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { FormFields(form, true, true, existing != null && existing.exp > 0) } },
        confirmButton = {
            TextButton(onClick = {
                val ep = form.endpoint.trim().ifEmpty { Gen.randomEndpoint() }
                val name = form.name.trim().ifEmpty { Gen.randomName("aether-") }
                val exp = if (form.unit == "keep") existing?.exp ?: 0L else Gen.expFrom(form.unit, form.amount)
                val cfg = parseLink(Gen.build(name, ep, form.protocol, form.scan, form.ip, exp))
                if (cfg == null) {
                    toast(ctx, "آدرس معتبر نیست؛ مثال: 162.159.192.1:2408")
                } else {
                    AppState.upsert(ctx, existing?.id, cfg)
                    toast(ctx, if (existing == null) "کانفیگ ساخته شد" else "ذخیره شد")
                    onClose()
                }
            }) { Text("تأیید") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("انصراف") } },
    )
}

@Composable
private fun PanelDialog(ctx: Context, onClose: () -> Unit) {
    val form = remember { Form() }
    var url by remember { mutableStateOf(AppState.panelUrl) }
    var pass by remember { mutableStateOf(AppState.panelPass) }
    val ltr = TextStyle(textDirection = TextDirection.Ltr)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("دریافت از پنل") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = url, onValueChange = { url = it.trim() }, singleLine = true, textStyle = ltr,
                    label = { Text("آدرس پنل (index.php)") }, placeholder = { Text("https://example.com/index.php") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = pass, onValueChange = { pass = it }, singleLine = true, textStyle = ltr,
                    label = { Text("رمز پنل (اگر دارد)") }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = form.count, onValueChange = { form.count = it.filter(Char::isDigit).take(3) }, singleLine = true,
                    label = { Text("تعداد کانفیگ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                FormFields(form, false, false, false)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (!url.startsWith("http")) {
                    toast(ctx, "آدرس پنل باید با http یا https شروع شود")
                } else {
                    AppState.panelUrl = url
                    AppState.panelPass = pass
                    AppState.save(ctx)
                    Panel.fetch(
                        ctx, url,
                        mapOf(
                            "api" to "1", "pass" to pass, "count" to form.count.ifEmpty { "5" },
                            "protocol" to form.protocol, "scan" to form.scan, "ip" to form.ip,
                            "unit" to form.unit, "amount" to form.amount,
                        ),
                    )
                    toast(ctx, "در حال دریافت…")
                    onClose()
                }
            }) { Text("دریافت") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("انصراف") } },
    )
}

// ---------------------------------------------------------------- screen

@Composable
private fun Home() {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn(ctx)
    }
    val onToggle: () -> Unit = {
        if (AppState.connected || AppState.busy) {
            stopVpn(ctx)
        } else if (AppState.configs.find { it.id == AppState.selected }?.expired == true) {
            toast(ctx, "این کانفیگ منقضی شده است")
        } else if (!AppState.testing && AppState.selected != null) {
            val i = if (AppState.vpnMode) VpnService.prepare(ctx) else null
            if (i != null) vpnLauncher.launch(i) else startVpn(ctx)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Header() }
        item { Hero(onToggle) }
        item { SectionBar(ctx, onCreate = { dlg = Dlg.Create }, onPanel = { dlg = Dlg.Panel }) }
        if (AppState.configs.isEmpty()) {
            item { EmptyCard() }
        } else {
            items(AppState.configs, key = { it.id }) { c -> CfgCard(ctx, c, onEdit = { dlg = Dlg.Edit(c) }) }
        }
        item { SettingsCard(ctx) }
        item { Spacer(Modifier.height(24.dp)) }
    }

    when (val d = dlg) {
        is Dlg.Create -> CfgDialog(ctx, null) { dlg = null }
        is Dlg.Edit -> CfgDialog(ctx, d.cfg) { dlg = null }
        is Dlg.Panel -> PanelDialog(ctx) { dlg = null }
        null -> {}
    }
}

@Composable
private fun Header() {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(cs.primary),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Default.Lock, null, tint = cs.onPrimary, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Aether", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = cs.onBackground)
            Text("اینترنت آزاد، یک‌لمسی", fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
    }
}

@Composable
private fun Hero(onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val state = AppState.state
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(AppState.connected) {
        while (AppState.connected) {
            now = SystemClock.elapsedRealtime()
            delay(1000)
        }
    }
    val selectedName = AppState.configs.find { it.id == AppState.selected }?.name

    Surface(
        shape = RoundedCornerShape(28.dp),
        color = cs.surface,
        border = BorderStroke(1.dp, cs.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 24.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            PowerButton(state, onToggle)
            Spacer(Modifier.height(16.dp))
            Text(
                when (state) { 2 -> "متصل"; 1 -> "در حال اتصال…"; else -> "قطع" },
                fontSize = 26.sp, fontWeight = FontWeight.Bold,
                color = when (state) { 2 -> cs.primary; 1 -> Amber; else -> cs.onSurface },
            )
            Spacer(Modifier.height(4.dp))
            val sub = when {
                state == 1 -> "پیدا کردن بهترین مسیر، تا ۹۰ ثانیه ممکن است طول بکشد"
                state == 0 && AppState.message.isNotEmpty() -> AppState.message
                state == 2 && !AppState.vpnMode -> "پراکسی SOCKS5 روی 127.0.0.1:1819 فعال است"
                selectedName != null -> selectedName
                else -> "یک کانفیگ بسازید، بچسبانید یا از پنل بگیرید"
            }
            Text(
                sub, fontSize = 13.sp, textAlign = TextAlign.Center,
                color = if (state == 0 && AppState.message.isNotEmpty()) cs.error else cs.onSurfaceVariant,
            )
            if (state == 2) {
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stat("زمان", fmtTime(now - AppState.connectedAt))
                    Stat("دانلود", fmtBytes(AppState.rxBytes))
                    Stat("آپلود", fmtBytes(AppState.txBytes))
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    val cs = MaterialTheme.colorScheme
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = cs.onSurface)
        Text(label, fontSize = 11.sp, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun PowerButton(state: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val inf = rememberInfiniteTransition(label = "pulse")
    val pulse by inf.animateFloat(
        initialValue = 0.93f, targetValue = 1.07f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue",
    )
    val base = when (state) { 2 -> cs.primary; 1 -> Amber; else -> cs.onSurfaceVariant }
    val col by animateColorAsState(base, label = "powerColor")
    Box(Modifier.size(180.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(180.dp).scale(if (state == 1) pulse else 1f).clip(CircleShape).background(col.copy(alpha = 0.10f)))
        Box(Modifier.size(144.dp).clip(CircleShape).background(col.copy(alpha = 0.18f)))
        Box(
            Modifier.size(108.dp).clip(CircleShape).background(col).clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Default.Lock, contentDescription = "اتصال", tint = Color.White, modifier = Modifier.size(42.dp)) }
    }
}

@Composable
private fun SectionBar(ctx: Context, onCreate: () -> Unit, onPanel: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val canTest = !AppState.testing && !AppState.connected && !AppState.busy
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("کانفیگ‌ها (${AppState.configs.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = cs.onBackground)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = onCreate, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Create, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("ساخت کانفیگ")
            }
            FilledTonalButton(onClick = { pasteFromClipboard(ctx) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("چسباندن لینک")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onPanel, modifier = Modifier.weight(1f)) { Text("دریافت از پنل") }
            OutlinedButton(
                onClick = { Core.test(ctx, AppState.configs.toList()) },
                enabled = canTest && AppState.configs.isNotEmpty(),
                modifier = Modifier.weight(1f),
            ) {
                Icon(Icons.Default.Refresh, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("تست پینگ")
            }
        }
    }
}

@Composable
private fun EmptyCard() {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(20.dp), color = cs.surface,
        border = BorderStroke(1.dp, cs.outline), modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("هنوز کانفیگی ندارید", fontWeight = FontWeight.Bold, color = cs.onSurface)
            Spacer(Modifier.height(6.dp))
            Text(
                "یکی از سه راه: «ساخت کانفیگ» برای ساخت همین‌جا، «چسباندن لینک» برای لینک aether:// کپی‌شده، یا «دریافت از پنل» برای گرفتن از پنل PHP.",
                fontSize = 13.sp, textAlign = TextAlign.Center, color = cs.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun CfgCard(ctx: Context, c: Cfg, onEdit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val sel = AppState.selected == c.id
    val locked = AppState.connected || AppState.busy
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (sel) cs.primaryContainer else cs.surface,
        border = BorderStroke(if (sel) 1.5.dp else 1.dp, if (sel) cs.primary else cs.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier
                .clickable(enabled = !locked) { AppState.selected = c.id; AppState.save(ctx) }
                .padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(cs.primary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) { Text(c.badge, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    c.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = if (sel) cs.onPrimaryContainer else cs.onSurface,
                )
                Text(
                    if (c.locked) "${c.badge} • ${c.scan} • محافظت‌شده" else "${c.host}:${c.port} • ${c.scan}",
                    fontSize = 12.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant,
                )
                val st = c.licId?.let { AppState.lic[it] }
                val expShown = if (c.locked) (st?.exp ?: 0L) else c.exp
                val d = if (expShown > 0) SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(expShown * 1000)) else ""
                val info: String? = when {
                    c.locked && st == null -> "فعال‌سازی نشده (نیاز به اینترنت)"
                    c.locked && st?.status == "revoked" -> "ابطال شده"
                    c.locked && st?.status == "device" -> "روی دستگاه دیگری فعال است"
                    c.locked && st?.status == "unknown" -> "نامعتبر"
                    expShown > 0 -> if (c.expired) "منقضی شده ($d)" else "انقضا: $d"
                    c.locked -> "بدون انقضا"
                    else -> null
                }
                if (info != null) {
                    Text(info, fontSize = 11.sp, color = if (c.expired) Red else cs.onSurfaceVariant)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                    val pad = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    if (!c.locked) {
                        TextButton(onClick = onEdit, enabled = !locked && !AppState.testing, contentPadding = pad) {
                            Text("ویرایش", fontSize = 12.sp)
                        }
                        TextButton(onClick = { shareLink(ctx, c.raw) }, contentPadding = pad) {
                            Text("اشتراک", fontSize = 12.sp)
                        }
                    }
                    TextButton(
                        onClick = { AppState.remove(ctx, c.id) },
                        enabled = !locked && !AppState.testing, contentPadding = pad,
                    ) { Text("حذف", fontSize = 12.sp, color = if (locked) cs.onSurfaceVariant else Red) }
                }
            }
            DelayPill(ctx, c)
        }
    }
}

@Composable
private fun DelayPill(ctx: Context, c: Cfg) {
    val cs = MaterialTheme.colorScheme
    if (AppState.testingId == c.id) {
        Box(Modifier.width(64.dp).height(32.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = cs.primary)
        }
        return
    }
    val (txt, col) = when {
        c.delay == 0 -> "تست" to cs.onSurfaceVariant
        c.delay < 0 -> "خطا" to Red
        c.delay < 800 -> "${c.delay} ms" to Green
        else -> "${c.delay} ms" to Amber
    }
    val canTest = !AppState.testing && !AppState.connected && !AppState.busy && !c.expired
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(col.copy(alpha = 0.15f))
            .clickable(enabled = canTest) { Core.test(ctx, listOf(c)) }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) { Text(txt, color = col, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
}

@Composable
private fun SettingsCard(ctx: Context) {
    val cs = MaterialTheme.colorScheme
    val locked = AppState.connected || AppState.busy || AppState.testing
    Surface(
        shape = RoundedCornerShape(20.dp), color = cs.surface,
        border = BorderStroke(1.dp, cs.outline), modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("تنظیمات", fontWeight = FontWeight.Bold, color = cs.onSurface)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("حالت VPN (کل گوشی)", fontSize = 14.sp, color = cs.onSurface)
                    Text("خاموش = فقط پراکسی SOCKS5 روی 127.0.0.1:1819 برای برنامه‌هایی مثل تلگرام یا v2rayNG", fontSize = 11.sp, color = cs.onSurfaceVariant)
                }
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = AppState.vpnMode, enabled = !locked,
                    onCheckedChange = { AppState.vpnMode = it; AppState.save(ctx) },
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("اتصال مستقیم به آدرس لینک", fontSize = 14.sp, color = cs.onSurface)
                    Text("به‌جای اسکن، از همان آی‌پی و پورت لینک استفاده می‌شود (سریع‌تر، ولی ممکن است روی همه شبکه‌ها کار نکند)", fontSize = 11.sp, color = cs.onSurfaceVariant)
                }
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = AppState.usePeer, enabled = !locked,
                    onCheckedChange = { AppState.usePeer = it; AppState.save(ctx) },
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("نمایش لاگ", fontSize = 14.sp, color = cs.onSurface, modifier = Modifier.weight(1f))
                Switch(checked = AppState.showLog, onCheckedChange = { AppState.showLog = it })
            }
            if (AppState.showLog) {
                Spacer(Modifier.height(8.dp))
                Text(
                    AppState.log.takeLast(14).joinToString("\n").ifEmpty { "—" },
                    fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = cs.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

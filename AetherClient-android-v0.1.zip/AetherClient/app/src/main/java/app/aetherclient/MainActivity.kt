package app.aetherclient

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppState.load(this)
        handle(intent)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { App() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val d = i?.dataString ?: return
        val n = AppState.addLinks(this, d)
        Toast.makeText(this, if (n > 0) "کانفیگ اضافه شد" else "لینک معتبر نبود یا تکراری بود", Toast.LENGTH_SHORT).show()
    }
}

private fun pasteFromClipboard(ctx: Context) {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
    val n = AppState.addLinks(ctx, t)
    Toast.makeText(ctx, if (n > 0) "$n کانفیگ اضافه شد" else "لینک aether:// در کلیپ‌بورد پیدا نشد", Toast.LENGTH_SHORT).show()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Aether Client") },
                    actions = {
                        TextButton(onClick = { pasteFromClipboard(ctx) }) { Text("چسباندن") }
                        TextButton(
                            enabled = !AppState.testing && !AppState.connected && !AppState.busy,
                            onClick = { Core.testAll(ctx) },
                        ) { Text("تست پینگ") }
                    },
                )
            },
            bottomBar = { BottomPanel(ctx) },
        ) { pad ->
            if (AppState.configs.isEmpty()) {
                Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لینک aether:// را کپی کنید و «چسباندن» را بزنید", Modifier.padding(24.dp))
                }
            } else {
                LazyColumn(Modifier.padding(pad)) {
                    items(AppState.configs, key = { it.id }) { c -> Row2(ctx, c) }
                }
            }
        }
    }
}

@Composable
private fun Row2(ctx: Context, c: Cfg) {
    Row(
        Modifier.fillMaxWidth().clickable { AppState.selected = c.id; AppState.save(ctx) }.padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = AppState.selected == c.id, onClick = { AppState.selected = c.id; AppState.save(ctx) })
        Column(Modifier.weight(1f)) {
            Text(c.name, fontWeight = FontWeight.Bold)
            Text("${c.protocol.uppercase()} • ${c.scan} • ${c.host}:${c.port}", fontSize = 12.sp)
        }
        val (txt, col) = when {
            c.delay == 0 -> "—" to Color.Gray
            c.delay < 0 -> "خطا" to Color(0xFFC62828)
            c.delay < 800 -> "${c.delay} ms" to Color(0xFF2E7D32)
            else -> "${c.delay} ms" to Color(0xFFEF6C00)
        }
        Text(txt, color = col, fontWeight = FontWeight.Bold)
        IconButton(
            enabled = !AppState.connected && !AppState.busy && !AppState.testing,
            onClick = { AppState.remove(ctx, c.id) },
        ) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
    }
}

@Composable
private fun BottomPanel(ctx: Context) {
    var showLog by remember { mutableStateOf(false) }
    Surface(tonalElevation = 3.dp) {
        Column(Modifier.fillMaxWidth().padding(12.dp).navigationBarsPadding()) {
            Text(AppState.status, fontWeight = FontWeight.Bold)
            if (AppState.connected) {
                Text("نسخه ۱ فقط پراکسی محلی است؛ در اپ‌ها SOCKS5 را روی 127.0.0.1:${Core.MAIN_PORT} تنظیم کنید.", fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = AppState.usePeer,
                    enabled = !AppState.connected && !AppState.busy && !AppState.testing,
                    onCheckedChange = { AppState.usePeer = it; AppState.save(ctx) },
                )
                Spacer(Modifier.width(8.dp))
                Text("استفاده از آدرس لینک به‌عنوان --peer", fontSize = 13.sp)
            }
            Row {
                Button(
                    modifier = Modifier.weight(1f),
                    enabled = !AppState.testing && (AppState.connected || AppState.busy || AppState.selected != null),
                    onClick = {
                        if (AppState.connected || AppState.busy) {
                            ctx.startService(Intent(ctx, ProxyService::class.java).setAction("stop"))
                        } else {
                            ctx.startForegroundService(Intent(ctx, ProxyService::class.java).putExtra("id", AppState.selected))
                        }
                    },
                ) { Text(if (AppState.connected || AppState.busy) "قطع اتصال" else "اتصال") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { showLog = !showLog }) { Text("لاگ") }
            }
            if (showLog) {
                Text(
                    AppState.log.takeLast(10).joinToString("\n"),
                    fontFamily = FontFamily.Monospace, fontSize = 10.sp,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}
